# TrueWeb Android v0.2

Рабочий этап приложения TrueWeb с реальной связкой с backend.

## Уже работает в коде

- экран входа через Telegram;
- кнопка Telegram Proxy через backend TrueWeb;
- callback `trueweb://auth/callback`;
- обмен одноразового auth-кода на session token;
- получение реальной подписки из `/api/mobile/me`;
- реальный срок подписки;
- реальный накопленный трафик из 3x-ui;
- реальное количество HWID-устройств и лимит;
- активация 3-дневного пробного периода прямо в приложении;
- новый пользователь создаётся в базе TrueWeb и 3x-ui без `/start` в Telegram-боте;
- кнопка обновления данных;
- logout;
- Android VpnService permission shell.

## Пока не включено

Сам VLESS/Reality core. Кнопка 🌐 в v0.2 получает системное разрешение Android VPN, но не запускает сетевой туннель. Это следующий этап.

## Backend

Приложение ожидает API:

`https://trueweb24.ru:8443/api/mobile`

Telegram Login callback:

`https://trueweb24.ru:8443/api/mobile/auth/telegram/callback`

Backend должен иметь `TELEGRAM_LOGIN_CLIENT_ID` и `TELEGRAM_LOGIN_CLIENT_SECRET`.

package ru.trueweb.vpn

object AppConfig {
    const val API_BASE = "https://trueweb24.ru/api/mobile"

    // Backend starts Telegram OIDC and eventually redirects to:
    // trueweb://auth/callback?code=ONE_TIME_CODE
    const val APP_AUTH_CALLBACK = "https://trueweb24.ru/mobile-auth/callback"

    const val TELEGRAM_AUTH_START =
        "$API_BASE/auth/telegram/start?return_to=https%3A%2F%2Ftrueweb24.ru%2Fmobile-auth%2Fcallback"

    // Replace with the current TrueWeb MTProto link before release.
    const val TELEGRAM_PROXY_URL =
        "https://t.me/proxy?server=YOUR_PROXY_HOST&port=443&secret=YOUR_PROXY_SECRET"
}

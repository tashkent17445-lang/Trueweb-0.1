package ru.trueweb.vpn

import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import ru.trueweb.vpn.api.TrueWebApi
import ru.trueweb.vpn.auth.AuthBackend
import ru.trueweb.vpn.auth.SessionStore
import ru.trueweb.vpn.model.SubscriptionInfo
import ru.trueweb.vpn.model.VpnServer
import ru.trueweb.vpn.store.DeviceIdentity
import ru.trueweb.vpn.store.ServerStore
import ru.trueweb.vpn.store.ThemeStore
import ru.trueweb.vpn.ui.*
import ru.trueweb.vpn.vpn.TrueWebVpnService
import ru.trueweb.vpn.work.SubscriptionRefreshWorker

class MainActivity : ComponentActivity() {
    private lateinit var sessionStore: SessionStore
    private lateinit var serverStore: ServerStore
    private lateinit var deviceIdentity: DeviceIdentity
    private lateinit var themeStore: ThemeStore

    private var authenticated by mutableStateOf(false)
    private var authInProgress by mutableStateOf(false)
    private var authError by mutableStateOf<String?>(null)

    private var subscription by mutableStateOf<SubscriptionInfo?>(null)
    private var servers by mutableStateOf<List<VpnServer>>(emptyList())
    private var selectedServerId by mutableStateOf("auto")
    private var themeMode by mutableStateOf(TrueWebThemeMode.DARK)

    private var profileLoading by mutableStateOf(false)
    private var profileError by mutableStateOf<String?>(null)
    private var trialLoading by mutableStateOf(false)

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                TrueWebVpnService.start(this)
            } else {
                Toast.makeText(this, "Без разрешения Android VPN подключение невозможно", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sessionStore = SessionStore(this)
        serverStore = ServerStore(this)
        deviceIdentity = DeviceIdentity(this)
        themeStore = ThemeStore(this)

        authenticated = sessionStore.isAuthenticated
        servers = serverStore.loadServers()
        selectedServerId = serverStore.selectedServerId
        themeMode = themeStore.mode

        handleAuthIntent(intent)

        setContent {
            val vpnState by TrueWebVpnService.state.collectAsState()
            val vpnError by TrueWebVpnService.lastError.collectAsState()
            TrueWebTheme(themeMode) {
                SideEffect {
                    val lightBars = themeMode == TrueWebThemeMode.LIGHT
                    val controller = WindowCompat.getInsetsController(window, window.decorView)
                    controller.isAppearanceLightStatusBars = lightBars
                    controller.isAppearanceLightNavigationBars = lightBars
                }

                if (!authenticated) {
                    AuthScreen(
                        authInProgress = authInProgress,
                        errorText = authError,
                        themeMode = themeMode,
                        onProxyClick = { openExternal(AppConfig.TELEGRAM_PROXY_URL) },
                        onTelegramLoginClick = {
                            authError = null
                            openExternal(AppConfig.TELEGRAM_AUTH_START)
                        }
                    )
                } else {
                    val info = subscription
                    if (info == null) {
                        LoadingScreen(themeMode, errorText = profileError, onRetry = { loadData(forceServers = true) })
                    } else {
                        HomeScreen(
                            subscription = info,
                            servers = servers,
                            selectedServerId = selectedServerId,
                            refreshing = profileLoading,
                            trialLoading = trialLoading,
                            errorText = profileError,
                            vpnState = vpnState,
                            vpnError = vpnError,
                            themeMode = themeMode,
                            onConnectClick = { toggleVpn(info, vpnState) },
                            onTrialClick = { activateTrial() },
                            onRefresh = { loadData(forceServers = true) },
                            onServerSelected = { selectServer(it, vpnState) },
                            onThemeChanged = { setTheme(it) },
                            onLogout = { logout() }
                        )
                    }
                }
            }
        }

        if (authenticated) {
            SubscriptionRefreshWorker.schedule(this)
            loadData(forceServers = serverStore.isStale() || servers.none { !it.isAuto && !it.uri.isNullOrBlank() })
        }
    }

    override fun onResume() {
        super.onResume()
        if (this::sessionStore.isInitialized && authenticated && !profileLoading) {
            servers = serverStore.loadServers()
            selectedServerId = serverStore.selectedServerId
            loadData(forceServers = serverStore.isStale())
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAuthIntent(intent)
    }

    private fun handleAuthIntent(intent: Intent?) {
        val uri = intent?.data ?: return
        val isVerifiedAppLink = uri.scheme == "https" && uri.host == "trueweb24.ru" && uri.path == "/mobile-auth/callback"
        val isAppScheme = uri.scheme == "trueweb" && uri.host == "auth" && uri.path == "/callback"
        if (!isVerifiedAppLink && !isAppScheme) return

        val error = uri.getQueryParameter("error")
        if (!error.isNullOrBlank()) {
            authError = error
            authInProgress = false
            return
        }

        val code = uri.getQueryParameter("code") ?: return
        authInProgress = true
        authError = null
        Thread {
            val result = AuthBackend.exchangeCode(code)
            runOnUiThread {
                authInProgress = false
                result.onSuccess { accessToken ->
                    sessionStore.accessToken = accessToken
                    authenticated = true
                    subscription = null
                    SubscriptionRefreshWorker.schedule(this)
                    loadData(forceServers = true)
                }.onFailure {
                    authError = "Не удалось завершить вход: ${cleanError(it)}"
                }
            }
        }.start()
    }

    private fun loadData(forceServers: Boolean) {
        if (profileLoading) return
        val token = sessionStore.accessToken ?: return
        profileLoading = true
        profileError = null

        Thread {
            var serverError: Throwable? = null
            var catalogUpdated = false
            if (forceServers || serverStore.isStale() || serverStore.loadServers().none { !it.isAuto && !it.uri.isNullOrBlank() }) {
                TrueWebApi.servers(token, deviceIdentity)
                    .onSuccess {
                        serverStore.saveCatalog(it)
                        catalogUpdated = true
                    }
                    .onFailure { serverError = it }
            }

            val profileResult = TrueWebApi.me(token)
            runOnUiThread {
                profileLoading = false
                if (catalogUpdated) {
                    servers = serverStore.loadServers()
                    selectedServerId = serverStore.selectedServerId
                }

                profileResult.onSuccess {
                    subscription = it
                    profileError = serverError?.let(::serverErrorText)
                }.onFailure {
                    if ((it.message ?: "").contains("HTTP 401")) {
                        expireSession()
                    } else {
                        profileError = "Не удалось обновить данные: ${cleanError(it)}"
                    }
                }

                if (serverError != null && (serverError!!.message ?: "").contains("HTTP 401")) {
                    expireSession()
                }
            }
        }.start()
    }

    private fun activateTrial() {
        if (trialLoading) return
        val token = sessionStore.accessToken ?: return
        trialLoading = true
        profileError = null
        Thread {
            val result = TrueWebApi.activateTrial(token)
            runOnUiThread {
                trialLoading = false
                result.onSuccess {
                    subscription = it
                    Toast.makeText(this, "Пробный доступ активирован на 3 дня", Toast.LENGTH_LONG).show()
                    loadData(forceServers = true)
                }.onFailure { profileError = cleanError(it) }
            }
        }.start()
    }

    private fun toggleVpn(info: SubscriptionInfo, state: TrueWebVpnService.TunnelState) {
        if (state == TrueWebVpnService.TunnelState.RUNNING || state == TrueWebVpnService.TunnelState.CONNECTING) {
            TrueWebVpnService.stop(this)
            return
        }
        if (!info.active) {
            Toast.makeText(this, "Сначала активируйте пробный период или подписку", Toast.LENGTH_SHORT).show()
            return
        }

        val token = sessionStore.accessToken ?: return
        Thread {
            var error: Throwable? = null
            if (serverStore.isStale() || serverStore.loadServers().none { !it.isAuto && !it.uri.isNullOrBlank() }) {
                TrueWebApi.servers(token, deviceIdentity)
                    .onSuccess { serverStore.saveCatalog(it) }
                    .onFailure { error = it }
            }
            runOnUiThread {
                servers = serverStore.loadServers()
                selectedServerId = serverStore.selectedServerId
                if (error != null) {
                    profileError = serverErrorText(error!!)
                    Toast.makeText(this, profileError, Toast.LENGTH_LONG).show()
                } else if (servers.none { !it.isAuto && !it.uri.isNullOrBlank() }) {
                    profileError = "Нет доступных VPN-серверов"
                } else {
                    requestVpnPermissionAndStart()
                }
            }
        }.start()
    }

    private fun requestVpnPermissionAndStart() {
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) vpnPermissionLauncher.launch(prepareIntent)
        else TrueWebVpnService.start(this)
    }

    private fun selectServer(id: String, vpnState: TrueWebVpnService.TunnelState) {
        serverStore.selectedServerId = id
        selectedServerId = id
        if (vpnState == TrueWebVpnService.TunnelState.RUNNING) {
            Toast.makeText(this, "Переключаем сервер…", Toast.LENGTH_SHORT).show()
            TrueWebVpnService.reload(this)
        }
    }

    private fun setTheme(mode: TrueWebThemeMode) {
        themeStore.mode = mode
        themeMode = mode
    }

    private fun logout() {
        val token = sessionStore.accessToken
        TrueWebVpnService.stop(this)
        SubscriptionRefreshWorker.cancel(this)
        sessionStore.clear()
        serverStore.clearRuntime()
        subscription = null
        servers = listOf(ServerStore.autoServer())
        selectedServerId = "auto"
        profileError = null
        authenticated = false
        if (!token.isNullOrBlank()) Thread { TrueWebApi.logout(token) }.start()
    }

    private fun expireSession() {
        TrueWebVpnService.stop(this)
        SubscriptionRefreshWorker.cancel(this)
        sessionStore.clear()
        authenticated = false
        subscription = null
        authError = "Сессия истекла. Войдите через Telegram ещё раз."
    }

    private fun serverErrorText(t: Throwable): String {
        val msg = cleanError(t)
        return when {
            msg.contains("Лимит устройств", ignoreCase = true) -> msg
            (t.message ?: "").contains("HTTP 403") -> "Лимит устройств исчерпан. Удалите старое устройство или добавьте слот."
            else -> "Не удалось обновить серверы: $msg"
        }
    }

    private fun openExternal(url: String) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            .onFailure { Toast.makeText(this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show() }
    }

    private fun cleanError(t: Throwable): String {
        val raw = t.message ?: "неизвестная ошибка"
        return raw.substringAfter(": ", raw).take(220)
    }
}

@Composable
private fun LoadingScreen(themeMode: TrueWebThemeMode, errorText: String?, onRetry: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(28.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (errorText.isNullOrBlank()) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(18.dp))
                    Text("Загружаем подписку…", color = MaterialTheme.colorScheme.onBackground)
                } else {
                    Text(errorText, color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onRetry) { Text("Повторить") }
                }
            }
        }
    }
}

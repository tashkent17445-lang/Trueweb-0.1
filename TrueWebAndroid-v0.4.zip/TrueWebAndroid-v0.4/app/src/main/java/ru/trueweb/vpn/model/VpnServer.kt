package ru.trueweb.vpn.model

import org.json.JSONArray
import org.json.JSONObject

data class VpnServer(
    val id: String,
    val name: String,
    val protocol: String,
    val uri: String?,
    val available: Boolean
) {
    val isAuto: Boolean get() = id == "auto"

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("protocol", protocol)
        put("uri", uri ?: JSONObject.NULL)
        put("available", available)
    }

    companion object {
        fun fromJson(obj: JSONObject): VpnServer = VpnServer(
            id = obj.optString("id"),
            name = obj.optString("name", "Сервер"),
            protocol = obj.optString("protocol", "vless"),
            uri = if (obj.isNull("uri")) null else obj.optString("uri", "").takeIf { it.isNotBlank() && it != "null" },
            available = obj.optBoolean("available", true)
        )

        fun listFromJson(array: JSONArray): List<VpnServer> = buildList {
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val server = fromJson(obj)
                if (server.id.isNotBlank()) add(server)
            }
        }
    }
}

data class ServerCatalog(
    val servers: List<VpnServer>,
    val devicesUsed: Int,
    val devicesLimit: Int,
    val refreshIntervalSeconds: Long
) {
    companion object {
        fun fromApi(root: JSONObject): ServerCatalog {
            val devices = root.optJSONObject("devices") ?: JSONObject()
            return ServerCatalog(
                servers = VpnServer.listFromJson(root.optJSONArray("servers") ?: JSONArray()),
                devicesUsed = devices.optInt("used", 0),
                devicesLimit = devices.optInt("limit", 0),
                refreshIntervalSeconds = root.optLong("refresh_interval_seconds", 3600L).coerceAtLeast(900L)
            )
        }
    }
}

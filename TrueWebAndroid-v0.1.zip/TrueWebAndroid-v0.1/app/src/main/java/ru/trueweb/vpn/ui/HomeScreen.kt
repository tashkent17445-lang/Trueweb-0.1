package ru.trueweb.vpn.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.trueweb.vpn.model.SubscriptionInfo

@Composable
fun HomeScreen(
    subscription: SubscriptionInfo,
    onConnectClick: () -> Unit,
    onServerClick: () -> Unit,
    onLogout: () -> Unit
) {
    var connected by remember { mutableStateOf(false) }
    val globeBg by animateColorAsState(
        if (connected) Color(0xFF38D39F) else Color(0xFF13263A),
        label = "globeBackground"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF07111E), Color(0xFF0A1D2B), Color(0xFF07111E))
                )
            )
            .padding(horizontal = 20.dp)
            .padding(top = 24.dp, bottom = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("TrueWeb", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onLogout) { Text("Выйти") }
        }

        Spacer(Modifier.height(22.dp))

        Surface(
            modifier = Modifier.fillMaxWidth().clickable(onClick = onServerClick),
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(18.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Сервер", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                    Text("⚡ ${subscription.serverName}", fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.weight(1f))
                subscription.latencyMs?.let {
                    Text("$it мс", color = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.width(8.dp))
                Text("›", fontSize = 28.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Spacer(Modifier.weight(0.7f))

        Surface(
            modifier = Modifier
                .size(190.dp)
                .shadow(28.dp, CircleShape)
                .clickable {
                    connected = !connected
                    onConnectClick()
                },
            shape = CircleShape,
            color = globeBg
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("🌐", fontSize = 92.sp)
            }
        }

        Spacer(Modifier.height(20.dp))
        Text(
            if (connected) "Подключено" else "Нажмите, чтобы подключиться",
            fontWeight = FontWeight.SemiBold,
            color = if (connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )
        if (connected) {
            Spacer(Modifier.height(4.dp))
            Text(
                "${subscription.serverName}${subscription.latencyMs?.let { " • $it мс" } ?: ""}",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
        }

        Spacer(Modifier.weight(0.8f))

        SubscriptionCard(subscription)
    }
}

@Composable
private fun SubscriptionCard(info: SubscriptionInfo) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Подписка", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                    Text(
                        if (info.active) "Активна" else "Не активна",
                        fontWeight = FontWeight.Bold,
                        color = if (info.active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                    )
                }
                Spacer(Modifier.weight(1f))
                Text("${info.daysLeft} дней", fontWeight = FontWeight.SemiBold)
            }

            Spacer(Modifier.height(10.dp))
            Text(
                "до ${info.expiresAt}",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(18.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            Spacer(Modifier.height(18.dp))

            Row(Modifier.fillMaxWidth()) {
                Metric("Трафик", info.trafficUsed, Modifier.weight(1f))
                Metric("Устройства", "${info.devicesUsed} из ${info.devicesLimit}", Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.Start) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(4.dp))
        Text(value, fontWeight = FontWeight.Bold, fontSize = 19.sp)
    }
}

package ru.trueweb.vpn.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

enum class TrueWebThemeMode { DARK, AMOLED }

private val DarkColors = darkColorScheme(
    primary = Color(0xFF38D39F),
    onPrimary = Color(0xFF002117),
    secondary = Color(0xFF79E8C2),
    background = Color(0xFF07111E),
    surface = Color(0xFF0D1B2A),
    surfaceVariant = Color(0xFF13263A),
    onBackground = Color(0xFFF3F7FA),
    onSurface = Color(0xFFF3F7FA),
    onSurfaceVariant = Color(0xFFB7C5D1),
    error = Color(0xFFFF6B6B)
)

private val AmoledColors = darkColorScheme(
    primary = Color(0xFF38D39F),
    onPrimary = Color(0xFF002117),
    secondary = Color(0xFF79E8C2),
    background = Color.Black,
    surface = Color(0xFF090909),
    surfaceVariant = Color(0xFF151515),
    onBackground = Color(0xFFF7F7F7),
    onSurface = Color(0xFFF7F7F7),
    onSurfaceVariant = Color(0xFFBDBDBD),
    error = Color(0xFFFF6B6B)
)

fun trueWebBackground(mode: TrueWebThemeMode): Brush = when (mode) {
    TrueWebThemeMode.AMOLED -> Brush.verticalGradient(listOf(Color.Black, Color.Black))
    TrueWebThemeMode.DARK -> Brush.verticalGradient(
        listOf(Color(0xFF07111E), Color(0xFF0A1D2B), Color(0xFF07111E))
    )
}

@Composable
fun TrueWebTheme(mode: TrueWebThemeMode = TrueWebThemeMode.DARK, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (mode == TrueWebThemeMode.AMOLED) AmoledColors else DarkColors, content = content)
}

# TrueWeb v0.8.4 — deployment notes

## Android / GitHub

The repository workflow expects `TrueWebAndroid-v0.4.zip` at repository root.

1. Upload `TrueWebAndroid-v0.4.zip` from this bundle, replacing the existing repository file.
2. Replace `.github/workflows/build-apk.yml` with the file from this bundle.
3. Commit both changes together if possible.
4. Open GitHub Actions and verify `Build TrueWeb APK v0.8.4 Release` finishes successfully.
5. Download artifact `TrueWeb-v0.8.4-Release` and verify its SHA-256 and APK signature before distribution.

Do not change the Android package name (`ru.trueweb.vpn`) or release signing key.

## RU1 backend + legal pages

Copy these items from the bundle to one directory on RU1:

- `trueweb_v084_market_patch.py`
- `deploy_trueweb_v084_server.sh`
- `legal/`

Then run from that directory:

```bash
chmod +x deploy_trueweb_v084_server.sh
sudo ./deploy_trueweb_v084_server.sh
```

The script backs up `/opt/vpn-bot/bot.py`, applies only the 0.8.4 market patch, compiles the Python source, installs the legal pages under `/var/www/trueweb-start/legal`, checks nginx, restarts `vpn-bot.service`, and verifies the routes/files.

Important: do **not** re-apply the older email-auth patch to the live server. The live server already contains the safe synthetic-ID hotfix.

## New mobile API routes

- `POST /api/mobile/auth/password/login`
- `POST /api/mobile/account/password`
- `DELETE /api/mobile/account`
- `POST /api/mobile/errors/report`

The error-report endpoint is authenticated, re-sanitizes diagnostic text server-side, de-duplicates repeated reports, and forwards safe diagnostics to the administrator through the existing Telegram bot.

## 0.8.4 behaviour

- one visible VPN connect button;
- automatic `primary (1) -> backup (18) -> WL` fallback;
- WL is not user-selectable;
- automatic return from WL after three consecutive normal-path probes;
- email / Telegram / login+password authentication;
- first-run privacy consent;
- in-app legal documents and Telegram group link;
- account deletion with trial anti-abuse marker;
- no TrueWeb debug logging calls in release source;
- unexpected authenticated errors are sent to the backend without secrets or traffic contents.

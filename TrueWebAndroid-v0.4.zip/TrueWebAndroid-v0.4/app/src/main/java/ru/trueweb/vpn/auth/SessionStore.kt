package ru.trueweb.vpn.auth

import android.content.Context

class SessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("trueweb_session", Context.MODE_PRIVATE)

    var accessToken: String?
        get() = prefs.getString("access_token", null)
        set(value) {
            prefs.edit().apply {
                if (value == null) remove("access_token") else putString("access_token", value)
            }.apply()
        }

    val isAuthenticated: Boolean get() = !accessToken.isNullOrBlank()

    fun clear() {
        prefs.edit().clear().apply()
    }
}

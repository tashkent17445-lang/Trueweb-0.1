# TrueWeb Android v0.4

TrueWeb client with native Xray-core support for VLESS + XHTTP + REALITY.

## v0.4 changes

- Replaced sing-box/libbox with Xray-core via AndroidLibXrayLite.
- VLESS `type=xhttp` links are parsed directly from the authorized TrueWeb subscription.
- REALITY parameters (`sni`, `fp`, `pbk`, `sid`, `spx`, `pqv`) are preserved.
- `extra`, `mode`, `path`, and `host` are preserved for XHTTP.
- Auto selection uses Xray `leastPing` + `observatory`; manual server selection remains available.
- Android VpnService passes its TUN file descriptor directly to Xray.
- Subscription/server refresh remains hourly and HWID is still sent by the backend request.
- Dark + pure-black AMOLED themes remain available.

The project expects `app/libs/libv2ray.aar`. The GitHub Actions workflow downloads the pinned AndroidLibXrayLite release before building.

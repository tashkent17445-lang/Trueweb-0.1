package ru.trueweb.vpn.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.trueweb.vpn.model.*
import ru.trueweb.vpn.vpn.TrueWebVpnService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    subscription: SubscriptionInfo,
    whitelistConfigured: Boolean,
    refreshing: Boolean,
    trialLoading: Boolean,
    errorText: String?,
    vpnState: TrueWebVpnService.TunnelState,
    vpnError: String?,
    vpnMode: VpnMode,
    whitelistSuggested: Boolean,
    themeMode: TrueWebThemeMode,
    tariffs: List<TariffOption>,
    deviceProduct: DeviceProduct?,
    devices: List<DeviceItem>,
    managementLoading: Boolean,
    managementError: String?,
    paymentLoadingProduct: String?,
    paymentChecking: Boolean,
    paymentMessage: String?,
    hasPendingPayment: Boolean,
    onConnectClick: () -> Unit,
    onWhitelistClick: () -> Unit,
    onTrialClick: () -> Unit,
    onRefresh: () -> Unit,
    onManagementRefresh: () -> Unit,
    onPay: (String) -> Unit,
    onCheckPayment: () -> Unit,
    onDismissPendingPayment: () -> Unit,
    onDeleteDevice: (Int) -> Unit,
    onThemeChanged: (TrueWebThemeMode) -> Unit,
    onLogout: () -> Unit
) {
    var showSettings by remember { mutableStateOf(false) }
    var showSubscriptionManager by remember { mutableStateOf(false) }
    var showWhitelistWarning by remember { mutableStateOf(false) }
    var showWhitelistSoon by remember { mutableStateOf(false) }

    if (showSubscriptionManager) {
        LaunchedEffect(Unit) { onManagementRefresh() }
        SubscriptionManagementScreen(
            subscription = subscription,
            refreshing = refreshing,
            trialLoading = trialLoading,
            tariffs = tariffs,
            deviceProduct = deviceProduct,
            devices = devices,
            loading = managementLoading,
            errorText = managementError,
            paymentLoadingProduct = paymentLoadingProduct,
            paymentChecking = paymentChecking,
            paymentMessage = paymentMessage,
            hasPendingPayment = hasPendingPayment,
            onBack = { showSubscriptionManager = false },
            onRefresh = {
                onRefresh()
                onManagementRefresh()
            },
            onTrialClick = onTrialClick,
            onPay = onPay,
            onCheckPayment = onCheckPayment,
            onDismissPendingPayment = onDismissPendingPayment,
            onDeleteDevice = onDeleteDevice
        )
        return
    }

    val wlActive = vpnMode == VpnMode.WHITELIST &&
        (vpnState == TrueWebVpnService.TunnelState.RUNNING || vpnState == TrueWebVpnService.TunnelState.CONNECTING)
    val normalRunning = vpnMode == VpnMode.NORMAL && vpnState == TrueWebVpnService.TunnelState.RUNNING

    val pulseTransition = rememberInfiniteTransition(label = "wl-alert")
    val redPulse by pulseTransition.animateFloat(
        initialValue = 0.30f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1300),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wl-alert-alpha"
    )

    val wlBorder = when {
        wlActive -> Brush.horizontalGradient(
            listOf(TrueWebGreen, TrueWebGreen)
        )
        whitelistSuggested -> Brush.horizontalGradient(
            listOf(
                Color(0xFF7A1010).copy(alpha = redPulse),
                Color(0xFFE53935).copy(alpha = redPulse),
                Color(0xFF8D1010).copy(alpha = redPulse)
            )
        )
        else -> Brush.horizontalGradient(
            listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.outline)
        )
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "TrueWeb",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { showSettings = true }, modifier = Modifier.size(52.dp)) {
                    Text("⚙", fontSize = 28.sp, color = MaterialTheme.colorScheme.onBackground)
                }
            }

            if (!errorText.isNullOrBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    errorText,
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(Modifier.weight(0.8f))

            val buttonColor = when {
                normalRunning -> TrueWebGreen
                vpnState == TrueWebVpnService.TunnelState.CONNECTING -> if (themeMode == TrueWebThemeMode.LIGHT) Color(0xFFF0F1F2) else Color(0xFF171717)
                vpnState == TrueWebVpnService.TunnelState.ERROR -> if (themeMode == TrueWebThemeMode.LIGHT) Color(0xFFFBE5E8) else Color(0xFF3A1B22)
                else -> if (themeMode == TrueWebThemeMode.LIGHT) Color(0xFFF4F5F6) else Color(0xFF111111)
            }

            Surface(
                modifier = Modifier
                    .size(190.dp)
                    .shadow(if (themeMode == TrueWebThemeMode.DARK) 0.dp else 10.dp, CircleShape)
                    .clickable(onClick = onConnectClick),
                shape = CircleShape,
                color = buttonColor,
                border = BorderStroke(
                    if (normalRunning) 2.dp else 1.dp,
                    if (normalRunning) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                )
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("🌐", fontSize = 92.sp)
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                when {
                    vpnState == TrueWebVpnService.TunnelState.RUNNING && vpnMode == VpnMode.WHITELIST -> "Белые списки активны"
                    vpnState == TrueWebVpnService.TunnelState.RUNNING -> "Подключено"
                    vpnState == TrueWebVpnService.TunnelState.CONNECTING && vpnMode == VpnMode.WHITELIST -> "Белые списки: подключение…"
                    vpnState == TrueWebVpnService.TunnelState.CONNECTING -> "Подключение…"
                    vpnState == TrueWebVpnService.TunnelState.ERROR -> "Подключение недоступно"
                    subscription.active -> "Нажмите, чтобы подключиться"
                    subscription.trialAvailable -> "Активируйте бесплатный доступ"
                    else -> "Подписка не активна"
                },
                fontWeight = FontWeight.SemiBold,
                color = when {
                    normalRunning || wlActive -> MaterialTheme.colorScheme.primary
                    else -> MaterialTheme.colorScheme.onBackground
                }
            )

            Spacer(Modifier.height(14.dp))

            OutlinedButton(
                onClick = {
                    when {
                        wlActive -> onWhitelistClick()
                        !whitelistConfigured -> showWhitelistSoon = true
                        else -> showWhitelistWarning = true
                    }
                },
                modifier = Modifier
                    .fillMaxWidth(0.78f)
                    .height(52.dp),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(if (wlActive || whitelistSuggested) 2.dp else 1.dp, wlBorder),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = if (wlActive) TrueWebGreen else Color.Transparent,
                    contentColor = if (wlActive) Color.White else MaterialTheme.colorScheme.onBackground
                )
            ) {
                Text(
                    if (wlActive) "Белые списки · ВКЛ" else "Белые списки",
                    fontWeight = FontWeight.SemiBold
                )
            }

            if (vpnState == TrueWebVpnService.TunnelState.ERROR && !vpnError.isNullOrBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    vpnError,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                )
            }

            Spacer(Modifier.weight(0.9f))

            SubscriptionSummaryCard(
                info = subscription,
                onManage = { showSubscriptionManager = true }
            )
        }
    }

    if (showWhitelistSoon) {
        AlertDialog(
            onDismissRequest = { showWhitelistSoon = false },
            title = { Text("Совсем скоро…") },
            text = { Text("Режим «Белые списки» пока недоступен для этого подключения.") },
            confirmButton = {
                TextButton(onClick = { showWhitelistSoon = false }) { Text("Понятно") }
            }
        )
    }

    if (showWhitelistWarning) {
        AlertDialog(
            onDismissRequest = { showWhitelistWarning = false },
            title = { Text("⚠ Белые списки") },
            text = {
                Text(
                    "Используйте этот режим только в мобильной сети и только для мессенджеров.\n\n" +
                        "YouTube, видео, загрузка больших файлов и другой тяжёлый трафик через это подключение запрещены.\n\n" +
                        "Нецелевое использование фиксируется автоматически. При нарушении доступ к режиму «Белые списки» будет заблокирован."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showWhitelistWarning = false
                        onWhitelistClick()
                    }
                ) { Text("Подключить") }
            },
            dismissButton = {
                TextButton(onClick = { showWhitelistWarning = false }) { Text("Отмена") }
            }
        )
    }

    if (showSettings) {
        ModalBottomSheet(
            onDismissRequest = { showSettings = false },
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface
        ) {
            Text(
                "Настройки",
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Text("Тема", modifier = Modifier.padding(horizontal = 24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
            ThemeChoice("Светлая — белая", TrueWebThemeMode.LIGHT, themeMode, onThemeChanged)
            ThemeChoice("Тёмная — чёрная", TrueWebThemeMode.DARK, themeMode, onThemeChanged)
            HorizontalDivider(Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline)
            TextButton(
                onClick = { onRefresh(); showSettings = false },
                enabled = !refreshing,
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) { Text(if (refreshing) "Обновляем…" else "↻ Обновить данные") }
            TextButton(
                onClick = { onLogout(); showSettings = false },
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) { Text("Выйти", color = MaterialTheme.colorScheme.error) }
            Spacer(Modifier.navigationBarsPadding().height(16.dp))
        }
    }
}

@Composable
private fun SubscriptionManagementScreen(
    subscription: SubscriptionInfo,
    refreshing: Boolean,
    trialLoading: Boolean,
    tariffs: List<TariffOption>,
    deviceProduct: DeviceProduct?,
    devices: List<DeviceItem>,
    loading: Boolean,
    errorText: String?,
    paymentLoadingProduct: String?,
    paymentChecking: Boolean,
    paymentMessage: String?,
    hasPendingPayment: Boolean,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onTrialClick: () -> Unit,
    onPay: (String) -> Unit,
    onCheckPayment: () -> Unit,
    onDismissPendingPayment: () -> Unit,
    onDeleteDevice: (Int) -> Unit
) {
    var deviceToDelete by remember { mutableStateOf<DeviceItem?>(null) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                    Text("‹", fontSize = 36.sp, color = MaterialTheme.colorScheme.onBackground)
                }
                Spacer(Modifier.width(4.dp))
                Text(
                    "Управление подпиской",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            if (loading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            }

            if (!errorText.isNullOrBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(errorText, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            Spacer(Modifier.height(16.dp))

            TrueWebCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("Подписка", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        when {
                            subscription.trialPending -> "Пробный доступ готов"
                            subscription.active -> "Активна"
                            else -> "Не активна"
                        },
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (subscription.active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        when {
                            subscription.trialPending -> subscription.expiresLabel
                            subscription.unlimited -> "Без ограничения по сроку"
                            subscription.active -> "Действует до ${subscription.expiresLabel}"
                            else -> subscription.expiresLabel
                        },
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (subscription.active && !subscription.unlimited) {
                        Spacer(Modifier.height(4.dp))
                        Text("Осталось ${subscription.daysLeft} дн.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TrueWebCard(Modifier.weight(1f)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Трафик", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.height(6.dp))
                        Text(subscription.trafficUsed, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
                TrueWebCard(Modifier.weight(1f)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Устройства", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.height(6.dp))
                        Text(subscription.devicesLabel, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }

            if (subscription.trialAvailable) {
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = onTrialClick,
                    enabled = !trialLoading,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    if (trialLoading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    else Text("Получить 3 дня бесплатно", fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Продление и оплата", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            if (subscription.unlimited) {
                TrueWebCard(Modifier.fillMaxWidth()) {
                    Text(
                        "У вас безлимитная подписка — продление не требуется.",
                        modifier = Modifier.padding(18.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else if (tariffs.isEmpty() && !loading) {
                TrueWebCard(Modifier.fillMaxWidth()) {
                    Text("Тарифы пока не загружены", modifier = Modifier.padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                tariffs.forEach { tariff ->
                    Spacer(Modifier.height(8.dp))
                    TariffButton(
                        tariff = tariff,
                        loading = paymentLoadingProduct == tariff.code,
                        enabled = paymentLoadingProduct == null && !paymentChecking,
                        onClick = { onPay(tariff.code) }
                    )
                }
            }

            if (!paymentMessage.isNullOrBlank() || hasPendingPayment) {
                Spacer(Modifier.height(12.dp))
                TrueWebCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text(paymentMessage ?: "Есть незавершённый платёж", color = MaterialTheme.colorScheme.onSurface)
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = onCheckPayment,
                            enabled = !paymentChecking,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (paymentChecking) {
                                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                                Text("Проверяем…")
                            } else Text("Проверить оплату")
                        }
                        TextButton(
                            onClick = onDismissPendingPayment,
                            enabled = !paymentChecking,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Скрыть платёж", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Устройства", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text(subscription.devicesLabel, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(8.dp))

            if (devices.isEmpty()) {
                TrueWebCard(Modifier.fillMaxWidth()) {
                    Text(
                        if (loading) "Загружаем устройства…" else "Зарегистрированных устройств нет",
                        modifier = Modifier.padding(18.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                devices.forEach { device ->
                    Spacer(Modifier.height(8.dp))
                    DeviceRow(device = device, enabled = !loading, onDelete = { deviceToDelete = device })
                }
            }

            if (deviceProduct != null && subscription.devicesLimit > 0) {
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { onPay(deviceProduct.code) },
                    enabled = paymentLoadingProduct == null && !paymentChecking,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    if (paymentLoadingProduct == deviceProduct.code) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Создаём платёж…")
                    } else {
                        Text("+ Доп. устройство — ${deviceProduct.price} ₽", fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            OutlinedButton(
                onClick = onRefresh,
                enabled = !refreshing && !loading,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Text(if (refreshing || loading) "Обновляем…" else "Обновить данные") }

            Spacer(Modifier.height(24.dp))
        }
    }

    deviceToDelete?.let { device ->
        AlertDialog(
            onDismissRequest = { deviceToDelete = null },
            title = { Text("Удалить устройство?") },
            text = {
                Text(
                    if (device.isCurrent) "Это текущее устройство. После удаления оно может зарегистрироваться снова при обновлении подключения."
                    else "${device.title}\n\nПосле удаления освободится один слот."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    deviceToDelete = null
                    onDeleteDevice(device.id)
                }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deviceToDelete = null }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun TariffButton(tariff: TariffOption, loading: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().height(58.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        if (loading) {
            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
            Spacer(Modifier.width(8.dp))
            Text("Создаём платёж…")
        } else {
            Text(tariff.title, modifier = Modifier.weight(1f), textAlign = TextAlign.Start, fontWeight = FontWeight.SemiBold)
            if (tariff.badge.isNotBlank()) {
                Text("${tariff.badge}  ", style = MaterialTheme.typography.labelSmall)
            }
            Text("${tariff.price} ₽", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun DeviceRow(device: DeviceItem, enabled: Boolean, onDelete: () -> Unit) {
    TrueWebCard(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(device.title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                    if (device.isCurrent) {
                        Spacer(Modifier.width(8.dp))
                        Text("это устройство", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                    }
                }
                if (device.details.isNotBlank()) {
                    Spacer(Modifier.height(2.dp))
                    Text(device.details, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
                if (device.lastSeenMs > 0L) {
                    Spacer(Modifier.height(2.dp))
                    Text("Был онлайн: ${formatDeviceTime(device.lastSeenMs)}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                }
            }
            TextButton(onClick = onDelete, enabled = enabled) {
                Text("Удалить", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

private fun formatDeviceTime(value: Long): String {
    val ms = if (value < 10_000_000_000L) value * 1000L else value
    return runCatching { SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(ms)) }.getOrDefault("—")
}

@Composable
private fun ThemeChoice(
    label: String,
    mode: TrueWebThemeMode,
    selected: TrueWebThemeMode,
    onChange: (TrueWebThemeMode) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onChange(mode) }.padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = mode == selected, onClick = null)
        Spacer(Modifier.width(10.dp))
        Text(label, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun SubscriptionSummaryCard(info: SubscriptionInfo, onManage: () -> Unit) {
    TrueWebCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Подписка", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                    Text(
                        when {
                            info.trialPending -> "Пробный доступ готов"
                            info.active -> "Активна"
                            else -> "Не активна"
                        },
                        fontWeight = FontWeight.Bold,
                        color = if (info.active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                    )
                }
                Spacer(Modifier.weight(1f))
                if (info.active && !info.unlimited) Text("${info.daysLeft} дн.", fontWeight = FontWeight.SemiBold)
            }

            Spacer(Modifier.height(10.dp))
            Text(
                when {
                    info.trialPending -> info.expiresLabel
                    info.unlimited -> "Без ограничения по сроку"
                    info.active -> "до ${info.expiresLabel}"
                    else -> info.expiresLabel
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            Spacer(Modifier.height(16.dp))

            Row(Modifier.fillMaxWidth()) {
                Metric("Трафик", info.trafficUsed, Modifier.weight(1f))
                Metric("Устройства", info.devicesLabel, Modifier.weight(1f))
            }

            Spacer(Modifier.height(18.dp))
            Button(
                onClick = onManage,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Text("Управление подпиской", fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.Start) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(4.dp))
        Text(value, fontWeight = FontWeight.Bold, fontSize = 19.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun TrueWebCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        content = content
    )
}

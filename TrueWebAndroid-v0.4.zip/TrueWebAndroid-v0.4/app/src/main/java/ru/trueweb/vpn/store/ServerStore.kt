package ru.trueweb.vpn.store

import android.content.Context
import org.json.JSONArray
import ru.trueweb.vpn.model.ServerCatalog
import ru.trueweb.vpn.model.VpnServer

class ServerStore(context: Context) {
    private val prefs = context.getSharedPreferences("trueweb_vpn", Context.MODE_PRIVATE)

    var selectedServerId: String
        get() = prefs.getString("selected_server_id", "auto") ?: "auto"
        set(value) = prefs.edit().putString("selected_server_id", value).apply()

    var desiredRunning: Boolean
        get() = prefs.getBoolean("desired_running", false)
        set(value) = prefs.edit().putBoolean("desired_running", value).apply()

    val updatedAtMs: Long get() = prefs.getLong("servers_updated_at", 0L)

    fun isStale(nowMs: Long = System.currentTimeMillis()): Boolean =
        updatedAtMs <= 0L || nowMs - updatedAtMs >= 60L * 60L * 1000L

    fun loadServers(): List<VpnServer> {
        val raw = prefs.getString("servers_json", null).orEmpty()
        if (raw.isBlank()) return listOf(autoServer())
        return runCatching { VpnServer.listFromJson(JSONArray(raw)) }
            .getOrDefault(listOf(autoServer()))
            .ifEmpty { listOf(autoServer()) }
    }

    fun saveCatalog(catalog: ServerCatalog) {
        val normalized = if (catalog.servers.any { it.id == "auto" }) {
            catalog.servers
        } else {
            listOf(autoServer()) + catalog.servers
        }
        val array = JSONArray().apply { normalized.forEach { put(it.toJson()) } }
        prefs.edit()
            .putString("servers_json", array.toString())
            .putLong("servers_updated_at", System.currentTimeMillis())
            .apply()

        if (selectedServerId != "auto" && normalized.none { it.id == selectedServerId }) {
            selectedServerId = "auto"
        }
    }

    fun selectedServer(): VpnServer {
        val all = loadServers()
        return all.firstOrNull { it.id == selectedServerId }
            ?: all.firstOrNull { it.id == "auto" }
            ?: autoServer()
    }

    fun clearRuntime() {
        prefs.edit()
            .remove("servers_json")
            .remove("servers_updated_at")
            .putString("selected_server_id", "auto")
            .putBoolean("desired_running", false)
            .apply()
    }

    companion object {
        fun autoServer() = VpnServer(
            id = "auto",
            name = "Автовыбор",
            protocol = "urltest",
            uri = null,
            available = true
        )
    }
}

package ru.trueweb.vpn.vpn

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import ru.trueweb.vpn.model.VpnServer

object SingBoxConfigBuilder {
    private const val AUTO_TAG = "auto"

    fun build(servers: List<VpnServer>, selectedServerId: String): String {
        val nodes = servers.filter { !it.isAuto && it.available && !it.uri.isNullOrBlank() }
        require(nodes.isNotEmpty()) { "Нет доступных VPN-серверов" }

        val nodeTags = nodes.associate { it.id to nodeTag(it.id) }
        val selectedTag = if (selectedServerId == "auto") {
            AUTO_TAG
        } else {
            nodeTags[selectedServerId] ?: AUTO_TAG
        }

        val outbounds = JSONArray()
        outbounds.put(JSONObject().apply {
            put("type", "urltest")
            put("tag", AUTO_TAG)
            put("outbounds", JSONArray().apply { nodes.forEach { put(nodeTag(it.id)) } })
            put("url", "https://www.gstatic.com/generate_204")
            put("interval", "3m")
            put("tolerance", 50)
            put("interrupt_exist_connections", false)
        })
        nodes.forEach { outbounds.put(vlessOutbound(it)) }
        outbounds.put(JSONObject().put("type", "direct").put("tag", "direct-out"))

        return JSONObject().apply {
            put("log", JSONObject().put("level", "info").put("timestamp", true))
            put("inbounds", JSONArray().put(JSONObject().apply {
                put("type", "tun")
                put("tag", "tun-in")
                put("address", JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"))
                put("mtu", 1500)
                put("auto_route", true)
                put("strict_route", true)
                put("stack", "gvisor")
            }))
            put("outbounds", outbounds)
            put("route", JSONObject().apply {
                put("rules", JSONArray().put(JSONObject().apply {
                    put("inbound", JSONArray().put("tun-in"))
                    put("action", "sniff")
                }))
                put("final", selectedTag)
            })
        }.toString(2)
    }

    private fun vlessOutbound(server: VpnServer): JSONObject {
        val link = server.uri ?: error("Пустой VLESS URI")
        val uri = Uri.parse(link)
        require(uri.scheme.equals("vless", ignoreCase = true)) { "Поддерживается только VLESS" }

        val uuid = uri.userInfo?.substringBefore(':').orEmpty()
        val host = uri.host.orEmpty()
        val port = uri.port.takeIf { it > 0 } ?: 443
        require(uuid.isNotBlank() && host.isNotBlank()) { "Некорректная VLESS-ссылка: ${server.name}" }

        val flow = uri.getQueryParameter("flow").orEmpty()
        val security = uri.getQueryParameter("security").orEmpty().lowercase()
        val sni = uri.getQueryParameter("sni").orEmpty()
        val fingerprint = uri.getQueryParameter("fp").orEmpty().ifBlank { "chrome" }
        val publicKey = uri.getQueryParameter("pbk").orEmpty()
        val shortId = uri.getQueryParameter("sid").orEmpty()
        val alpn = uri.getQueryParameter("alpn").orEmpty()
        val transportType = uri.getQueryParameter("type").orEmpty().lowercase()
        val packetEncoding = uri.getQueryParameter("packetEncoding")
            ?: uri.getQueryParameter("packet_encoding")
            ?: ""

        return JSONObject().apply {
            put("type", "vless")
            put("tag", nodeTag(server.id))
            put("server", host)
            put("server_port", port)
            put("uuid", uuid)
            if (flow.isNotBlank()) put("flow", flow)
            if (packetEncoding.isNotBlank()) put("packet_encoding", packetEncoding)

            if (security == "reality" || security == "tls" || publicKey.isNotBlank()) {
                put("tls", JSONObject().apply {
                    put("enabled", true)
                    if (sni.isNotBlank()) put("server_name", sni)
                    if (alpn.isNotBlank()) {
                        put("alpn", JSONArray().apply {
                            alpn.split(',').map(String::trim).filter(String::isNotBlank).forEach(::put)
                        })
                    }
                    put("utls", JSONObject().put("enabled", true).put("fingerprint", fingerprint))
                    if (security == "reality" || publicKey.isNotBlank()) {
                        require(publicKey.isNotBlank()) { "В Reality-ссылке нет public key: ${server.name}" }
                        put("reality", JSONObject().apply {
                            put("enabled", true)
                            put("public_key", publicKey)
                            if (shortId.isNotBlank()) put("short_id", shortId)
                        })
                    }
                })
            }

            transport(uri, transportType)?.let { put("transport", it) }
        }
    }

    private fun transport(uri: Uri, type: String): JSONObject? = when (type) {
        "", "tcp", "raw" -> null
        "ws", "websocket" -> JSONObject().apply {
            put("type", "ws")
            put("path", uri.getQueryParameter("path").orEmpty().ifBlank { "/" })
            uri.getQueryParameter("host")?.takeIf(String::isNotBlank)?.let {
                put("headers", JSONObject().put("Host", it))
            }
        }
        "grpc" -> JSONObject().apply {
            put("type", "grpc")
            put("service_name", uri.getQueryParameter("serviceName") ?: uri.getQueryParameter("service_name") ?: "")
        }
        "httpupgrade", "http-upgrade" -> JSONObject().apply {
            put("type", "httpupgrade")
            put("path", uri.getQueryParameter("path").orEmpty().ifBlank { "/" })
            uri.getQueryParameter("host")?.takeIf(String::isNotBlank)?.let {
                put("headers", JSONObject().put("Host", it))
            }
        }
        "http", "h2" -> JSONObject().apply {
            put("type", "http")
            put("path", uri.getQueryParameter("path").orEmpty().ifBlank { "/" })
            uri.getQueryParameter("host")?.takeIf(String::isNotBlank)?.let {
                put("host", JSONArray().put(it))
            }
        }
        else -> error("Транспорт '$type' пока не поддерживается")
    }

    private fun nodeTag(id: String): String = "node-" + id.replace(Regex("[^A-Za-z0-9_-]"), "_")
}

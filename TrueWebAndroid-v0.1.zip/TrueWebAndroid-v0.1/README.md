# TrueWeb Android v0.1

Первый Android-каркас приложения TrueWeb.

## Уже есть

- экран авторизации;
- кнопка **«Подключить Telegram Proxy»**;
- кнопка **«Войти через Telegram»**;
- возврат авторизации в приложение через `https://trueweb24.ru/mobile-auth/callback` (verified Android App Link);
- обмен одноразового кода на access token через backend;
- главный экран с большой кнопкой 🌐;
- карточка подписки: срок, остаток дней, трафик, устройства;
- карточка выбора сервера;
- системный запрос Android на разрешение VPN;
- заготовка `TrueWebVpnService`.

## Важно: что пока НЕ подключено

v0.1 **не пропускает трафик через VPN**. `VpnService` специально не создаёт TUN-интерфейс, пока мы не подключим настоящий VLESS/Reality core. Это сделано намеренно: пустой TUN просто отрежет пользователю интернет.

Данные подписки на главном экране пока демонстрационные (`SubscriptionInfo.Preview`).

## 1. Telegram-авторизация без захода в бота

Пользователь не обязан открывать чат с ботом.

Рекомендуемый поток:

1. Приложение открывает:
   `GET https://trueweb24.ru/api/mobile/auth/telegram/start?return_to=https://trueweb24.ru/mobile-auth/callback`
2. Backend создаёт `state`, `nonce` и PKCE и перенаправляет на Telegram OIDC.
3. В BotFather для Login Widget регистрируется callback:
   `https://trueweb24.ru/api/mobile/auth/telegram/callback`
4. Telegram возвращает пользователя на backend.
5. Backend проверяет ID token (signature/JWKS, `iss`, `aud`, `exp`, `nonce`).
6. Backend находит/создаёт TrueWeb-пользователя по Telegram ID.
7. Backend создаёт короткоживущий одноразовый код (например 60 секунд, 1 использование).
8. Backend делает redirect:
   `https://trueweb24.ru/mobile-auth/callback?code=...`
9. Приложение вызывает:
   `POST https://trueweb24.ru/api/mobile/auth/exchange`
10. Backend возвращает access/refresh token TrueWeb.

**Client Secret Telegram никогда не должен попадать в APK.**

### Ожидаемый endpoint обмена

Request:

```json
{"code":"ONE_TIME_CODE"}
```

Response:

```json
{
  "access_token": "...",
  "refresh_token": "..."
}
```


### Android App Link

Чтобы callback гарантированно открывался именно в TrueWeb, на сервере нужно отдать:

`https://trueweb24.ru/.well-known/assetlinks.json`

В нём указываются package `ru.trueweb.vpn` и SHA-256 fingerprint релизного keystore. До настройки App Link в manifest оставлен dev/fallback `trueweb://auth/callback`, но production должен использовать HTTPS App Link.

## 2. Telegram Proxy

В файле:

`app/src/main/java/ru/trueweb/vpn/AppConfig.kt`

замени `TELEGRAM_PROXY_URL` на актуальную MTProto-ссылку TrueWeb вида:

`https://t.me/proxy?server=HOST&port=443&secret=SECRET`

## 3. API, который нужен дальше

Предлагаемый минимум:

- `POST /api/mobile/auth/exchange`
- `POST /api/mobile/auth/refresh`
- `GET /api/mobile/me`
- `GET /api/mobile/subscription`
- `GET /api/mobile/servers`
- `GET /api/mobile/vpn-config`
- `POST /api/mobile/device/register`
- `POST /api/mobile/device/remove`

`/vpn-config` должен отдавать только конфигурацию текущего авторизованного пользователя, а backend сам решает, какие серверы/UUID/Reality-параметры ему доступны.

## 4. Следующий шаг: реальный VPN

Нужно выбрать и встроить VLESS/Reality core. Варианты:

- Xray-core/libXray;
- sing-box/libbox (обязательно учитывать лицензию выбранной библиотеки/сборки).

После этого `TrueWebVpnService` будет:

1. получать конфиг с `/vpn-config`;
2. поднимать core;
3. создавать TUN через Android `VpnService`;
4. передавать TUN в core;
5. отдавать приложению статус, скорость и статистику.

## Сборка

Проект рассчитан на Android Studio с AGP 9.4.0 / Gradle 9.6.0 / compileSdk 37.

Открой папку проекта в Android Studio и дождись Gradle Sync.

Если wrapper отсутствует или IDE предлагает обновить его, можно использовать Gradle 9.6.0 из Android Studio.

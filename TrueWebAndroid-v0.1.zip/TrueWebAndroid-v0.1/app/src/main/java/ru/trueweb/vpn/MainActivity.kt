package ru.trueweb.vpn

import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import ru.trueweb.vpn.auth.AuthBackend
import ru.trueweb.vpn.auth.SessionStore
import ru.trueweb.vpn.model.SubscriptionInfo
import ru.trueweb.vpn.ui.AuthScreen
import ru.trueweb.vpn.ui.HomeScreen
import ru.trueweb.vpn.ui.TrueWebTheme

class MainActivity : ComponentActivity() {
    private lateinit var sessionStore: SessionStore
    private var authenticated by mutableStateOf(false)
    private var authInProgress by mutableStateOf(false)
    private var authError by mutableStateOf<String?>(null)

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                Toast.makeText(
                    this,
                    "Разрешение VPN получено. Следующий шаг — подключить VLESS/Reality core.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sessionStore = SessionStore(this)
        authenticated = sessionStore.isAuthenticated
        handleAuthIntent(intent)

        setContent {
            TrueWebTheme {
                if (!authenticated) {
                    AuthScreen(
                        authInProgress = authInProgress,
                        errorText = authError,
                        onProxyClick = { openExternal(AppConfig.TELEGRAM_PROXY_URL) },
                        onTelegramLoginClick = { openExternal(AppConfig.TELEGRAM_AUTH_START) }
                    )
                } else {
                    HomeScreen(
                        subscription = SubscriptionInfo.Preview,
                        onConnectClick = { requestVpnPermission() },
                        onServerClick = {
                            Toast.makeText(this, "Выбор сервера подключим к /servers", Toast.LENGTH_SHORT).show()
                        },
                        onLogout = {
                            sessionStore.clear()
                            authenticated = false
                        }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAuthIntent(intent)
    }

    private fun handleAuthIntent(intent: Intent?) {
        val uri = intent?.data ?: return
        val isVerifiedAppLink = uri.scheme == "https" && uri.host == "trueweb24.ru" && uri.path == "/mobile-auth/callback"
        val isDevScheme = uri.scheme == "trueweb" && uri.host == "auth" && uri.path == "/callback"
        if (!isVerifiedAppLink && !isDevScheme) return

        val error = uri.getQueryParameter("error")
        if (!error.isNullOrBlank()) {
            authError = error
            authInProgress = false
            return
        }

        val code = uri.getQueryParameter("code") ?: return
        authInProgress = true
        authError = null

        Thread {
            val result = AuthBackend.exchangeCode(code)
            runOnUiThread {
                authInProgress = false
                result.onSuccess { accessToken ->
                    sessionStore.accessToken = accessToken
                    authenticated = true
                }.onFailure {
                    authError = "Не удалось завершить вход: ${it.message ?: "неизвестная ошибка"}"
                }
            }
        }.start()
    }

    private fun requestVpnPermission() {
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            vpnPermissionLauncher.launch(prepareIntent)
        } else {
            Toast.makeText(
                this,
                "Разрешение уже есть. VLESS/Reality core пока не подключён в v0.1.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun openExternal(url: String) {
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }.onFailure {
            Toast.makeText(this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show()
        }
    }
}

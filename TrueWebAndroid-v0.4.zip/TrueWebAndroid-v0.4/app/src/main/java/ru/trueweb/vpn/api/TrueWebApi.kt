package ru.trueweb.vpn.api

import org.json.JSONObject
import ru.trueweb.vpn.AppConfig
import ru.trueweb.vpn.model.ServerCatalog
import ru.trueweb.vpn.model.SubscriptionInfo
import ru.trueweb.vpn.store.DeviceIdentity
import java.net.HttpURLConnection
import java.net.URL

object TrueWebApi {
    fun exchangeCode(code: String): Result<String> = runCatching {
        request(
            method = "POST",
            path = "/auth/exchange",
            body = JSONObject().put("code", code).toString()
        ).getString("access_token")
    }

    fun me(accessToken: String): Result<SubscriptionInfo> = runCatching {
        SubscriptionInfo.fromApi(request("GET", "/me", accessToken = accessToken))
    }

    fun servers(accessToken: String, device: DeviceIdentity): Result<ServerCatalog> = runCatching {
        val json = request(
            method = "GET",
            path = "/servers",
            accessToken = accessToken,
            extraHeaders = mapOf(
                "x-hwid" to device.hwid,
                "x-device-os" to device.osName,
                "x-device-model" to device.model,
                "x-ver-os" to device.osVersion
            )
        )
        ServerCatalog.fromApi(json)
    }

    fun activateTrial(accessToken: String): Result<SubscriptionInfo> = runCatching {
        SubscriptionInfo.fromApi(request("POST", "/trial", accessToken = accessToken, body = "{}"))
    }

    fun logout(accessToken: String): Result<Unit> = runCatching {
        request("POST", "/logout", accessToken = accessToken, body = "{}")
        Unit
    }

    private fun request(
        method: String,
        path: String,
        accessToken: String? = null,
        body: String? = null,
        extraHeaders: Map<String, String> = emptyMap()
    ): JSONObject {
        val connection = URL("${AppConfig.API_BASE}$path").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            connection.connectTimeout = 15_000
            connection.readTimeout = 25_000
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("User-Agent", "TrueWeb-Android/0.3")
            if (!accessToken.isNullOrBlank()) {
                connection.setRequestProperty("Authorization", "Bearer $accessToken")
            }
            extraHeaders.forEach { (key, value) -> connection.setRequestProperty(key, value) }
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }

            val responseCode = connection.responseCode
            val stream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val json = if (text.isBlank()) JSONObject() else runCatching { JSONObject(text) }.getOrElse {
                JSONObject().put("error", text.take(500))
            }

            if (responseCode !in 200..299) {
                val message = json.optString("error", "HTTP $responseCode")
                error("HTTP $responseCode: $message")
            }
            return json
        } finally {
            connection.disconnect()
        }
    }
}

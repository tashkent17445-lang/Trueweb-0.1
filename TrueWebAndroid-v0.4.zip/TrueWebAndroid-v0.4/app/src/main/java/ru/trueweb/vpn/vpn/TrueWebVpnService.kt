package ru.trueweb.vpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import android.util.Base64
import androidx.core.app.NotificationCompat
import go.Seq
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import ru.trueweb.vpn.MainActivity
import ru.trueweb.vpn.R
import ru.trueweb.vpn.store.DeviceIdentity
import ru.trueweb.vpn.store.ServerStore
import ru.trueweb.vpn.store.RoutingStore
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean

/** Native Android VPN service backed by Xray-core (AndroidLibXrayLite). */
class TrueWebVpnService : VpnService() {
    enum class TunnelState { STOPPED, CONNECTING, RUNNING, ERROR }

    companion object {
        const val ACTION_START = "ru.trueweb.vpn.START"
        const val ACTION_STOP = "ru.trueweb.vpn.STOP"
        const val ACTION_RELOAD = "ru.trueweb.vpn.RELOAD"
        private const val CHANNEL_ID = "trueweb_vpn"
        private const val NOTIFICATION_ID = 1001
        private const val TAG = "TrueWebXray"

        private val _state = MutableStateFlow(TunnelState.STOPPED)
        val state: StateFlow<TunnelState> = _state
        private val _lastError = MutableStateFlow<String?>(null)
        val lastError: StateFlow<String?> = _lastError

        fun start(context: Context) {
            context.startForegroundService(Intent(context, TrueWebVpnService::class.java).setAction(ACTION_START))
        }

        fun stop(context: Context) {
            context.startService(Intent(context, TrueWebVpnService::class.java).setAction(ACTION_STOP))
        }

        fun reload(context: Context) {
            context.startForegroundService(Intent(context, TrueWebVpnService::class.java).setAction(ACTION_RELOAD))
        }
    }

    private val starting = AtomicBoolean(false)
    private val store by lazy { ServerStore(applicationContext) }
    private val routingStore by lazy { RoutingStore(applicationContext) }
    private var tunFd: ParcelFileDescriptor? = null
    private var core: CoreController? = null

    private val callback = object : CoreCallbackHandler {
        override fun startup(): Long {
            Log.i(TAG, "Xray callback: startup")
            return 0
        }

        override fun shutdown(): Long {
            Log.i(TAG, "Xray callback: shutdown")
            return 0
        }

        override fun onEmitStatus(code: Long, message: String?): Long {
            Log.i(TAG, "Xray status $code: ${message.orEmpty()}")
            return 0
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        initializeCore()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                store.desiredRunning = false
                stopTunnel(clearError = true)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }

            ACTION_START, ACTION_RELOAD -> {
                store.desiredRunning = true
                startForeground(
                    NOTIFICATION_ID,
                    notification(if (intent.action == ACTION_RELOAD) "Переключаем сервер…" else "Подключение…")
                )
                startTunnelAsync()
            }

            else -> {
                if (!store.desiredRunning) return START_NOT_STICKY
                startForeground(NOTIFICATION_ID, notification("Восстанавливаем подключение…"))
                startTunnelAsync()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopTunnel(clearError = false)
        super.onDestroy()
    }

    override fun onRevoke() {
        store.desiredRunning = false
        stopTunnel(clearError = true)
        stopSelf()
        super.onRevoke()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (store.desiredRunning) updateNotification("TrueWeb работает в фоне")
        super.onTaskRemoved(rootIntent)
    }

    @Synchronized
    private fun initializeCore() {
        if (core != null) return
        Seq.setContext(applicationContext)
        ensureGeoAssets()
        val base = filesDir.absolutePath
        val hwid = DeviceIdentity(this).hwid
        val keyBytes = MessageDigest.getInstance("SHA-256")
            .digest(hwid.toByteArray(Charsets.UTF_8))
        val xudpBaseKey = Base64.encodeToString(
            keyBytes,
            Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
        )
        Libv2ray.initCoreEnv(base, xudpBaseKey)
        core = Libv2ray.newCoreController(callback)
        Log.i(TAG, "${Libv2ray.checkVersionX()}")
    }

    private fun startTunnelAsync() {
        if (!starting.compareAndSet(false, true)) return
        Thread {
            try {
                _lastError.value = null
                _state.value = TunnelState.CONNECTING
                updateNotification("Подключение…")

                initializeCore()
                stopCoreOnly()

                val servers = store.loadServers()
                val routingPolicy = routingStore.load()
                val built = XrayConfigBuilder.build(
                    servers = servers,
                    selectedServerId = store.selectedServerId,
                    smartAuto = routingPolicy.smartAuto,
                    bypassRu = routingPolicy.bypassRu
                )
                tunFd = establishVpnInterface()

                val controller = core ?: error("Xray-core не инициализирован")
                controller.startLoop(built.json, tunFd!!.fd)
                if (!controller.isRunning) error("Xray-core не запустился")

                _state.value = TunnelState.RUNNING
                _lastError.value = null
                updateNotification("VPN подключён · ${built.selectedName}")
                Log.i(TAG, "Tunnel started with ${built.nodeCount} Xray node(s), selected=${built.selectedName}")
            } catch (e: Throwable) {
                Log.e(TAG, "Start failed: ${e.message}", e)
                _lastError.value = friendlyError(e)
                _state.value = TunnelState.ERROR
                updateNotification("Ошибка VPN: ${friendlyError(e).take(90)}")
                stopCoreOnly()
            } finally {
                starting.set(false)
            }
        }.start()
    }

    private fun friendlyError(e: Throwable): String {
        val raw = (e.message ?: e.javaClass.simpleName).replace('\n', ' ').trim()
        return when {
            raw.contains("xhttp", ignoreCase = true) -> "XHTTP: $raw"
            raw.contains("reality", ignoreCase = true) -> "REALITY: $raw"
            raw.contains("config", ignoreCase = true) -> "Конфигурация Xray: $raw"
            else -> raw
        }.take(300)
    }

    private fun establishVpnInterface(): ParcelFileDescriptor {
        val builder = Builder()
            .setSession("TrueWeb")
            .setMtu(1500)
            .addAddress("172.16.0.2", 30)
            .addRoute("0.0.0.0", 0)
            .addAddress("fdfe:dcba:9876::2", 126)
            .addRoute("::", 0)
            .addDnsServer("77.88.8.8")
            .addDnsServer("1.1.1.1")

        // The native Xray process runs under the same app UID. Excluding our own UID
        // keeps its outbound sockets outside the VPN and prevents a routing loop.
        runCatching { builder.addDisallowedApplication(packageName) }

        // In Smart Auto mode selected Russian apps never enter the VPN interface at all.
        // This means they use the normal Wi-Fi/mobile route and see the normal public IP.
        if (store.selectedServerId == "auto") {
            val policy = routingStore.load()
            if (policy.smartAuto) {
                policy.excludedPackages.forEach { pkg ->
                    if (pkg != packageName) {
                        runCatching { builder.addDisallowedApplication(pkg) }
                            .onFailure { Log.d(TAG, "Bypass app not installed or unavailable: $pkg") }
                    }
                }
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) builder.setMetered(false)
        return builder.establish() ?: error("Android не создал VPN-интерфейс")
    }

    private fun ensureGeoAssets() {
        listOf("geoip.dat", "geosite.dat").forEach { name ->
            val target = File(filesDir, name)
            val tmp = File(filesDir, "$name.tmp")
            assets.open(name).use { input ->
                tmp.outputStream().use { output -> input.copyTo(output) }
            }
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) {
                tmp.copyTo(target, overwrite = true)
                tmp.delete()
            }
        }
    }

    @Synchronized
    private fun stopCoreOnly() {
        runCatching {
            val controller = core
            if (controller != null && controller.isRunning) controller.stopLoop()
        }.onFailure { Log.w(TAG, "Xray stop failed", it) }
        runCatching { tunFd?.close() }
        tunFd = null
    }

    private fun stopTunnel(clearError: Boolean) {
        stopCoreOnly()
        if (clearError) _lastError.value = null
        _state.value = TunnelState.STOPPED
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "TrueWeb VPN", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Подключение TrueWeb VPN"
                    setShowBadge(false)
                }
            )
        }
    }

    private fun notification(text: String): Notification {
        val pending = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("TrueWeb")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_trueweb)
            .setContentIntent(pending)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
    }
}

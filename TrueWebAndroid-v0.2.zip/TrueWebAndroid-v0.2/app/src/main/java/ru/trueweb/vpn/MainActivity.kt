package ru.trueweb.vpn

import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import ru.trueweb.vpn.api.TrueWebApi
import ru.trueweb.vpn.auth.AuthBackend
import ru.trueweb.vpn.auth.SessionStore
import ru.trueweb.vpn.model.SubscriptionInfo
import ru.trueweb.vpn.ui.AuthScreen
import ru.trueweb.vpn.ui.HomeScreen
import ru.trueweb.vpn.ui.TrueWebTheme

class MainActivity : ComponentActivity() {
    private lateinit var sessionStore: SessionStore

    private var authenticated by mutableStateOf(false)
    private var authInProgress by mutableStateOf(false)
    private var authError by mutableStateOf<String?>(null)

    private var subscription by mutableStateOf<SubscriptionInfo?>(null)
    private var profileLoading by mutableStateOf(false)
    private var profileError by mutableStateOf<String?>(null)
    private var trialLoading by mutableStateOf(false)

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                Toast.makeText(
                    this,
                    "Разрешение VPN получено. Следующий этап — включить VLESS/Reality-движок.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sessionStore = SessionStore(this)
        authenticated = sessionStore.isAuthenticated
        handleAuthIntent(intent)

        setContent {
            TrueWebTheme {
                if (!authenticated) {
                    AuthScreen(
                        authInProgress = authInProgress,
                        errorText = authError,
                        onProxyClick = { openExternal(AppConfig.TELEGRAM_PROXY_URL) },
                        onTelegramLoginClick = {
                            authError = null
                            openExternal(AppConfig.TELEGRAM_AUTH_START)
                        }
                    )
                } else {
                    val info = subscription
                    if (info == null) {
                        LoadingScreen(errorText = profileError, onRetry = { loadProfile() })
                    } else {
                        HomeScreen(
                            subscription = info,
                            refreshing = profileLoading,
                            trialLoading = trialLoading,
                            errorText = profileError,
                            onConnectClick = {
                                if (info.active) {
                                    requestVpnPermission()
                                } else {
                                    Toast.makeText(
                                        this,
                                        "Сначала активируйте пробный период или подписку.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            },
                            onTrialClick = { activateTrial() },
                            onRefresh = { loadProfile() },
                            onServerClick = {
                                Toast.makeText(this, "Сейчас включён Автовыбор", Toast.LENGTH_SHORT).show()
                            },
                            onLogout = { logout() }
                        )
                    }
                }
            }
        }

        if (authenticated) loadProfile()
    }

    override fun onResume() {
        super.onResume()
        if (this::sessionStore.isInitialized && authenticated && !profileLoading) {
            loadProfile()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAuthIntent(intent)
    }

    private fun handleAuthIntent(intent: Intent?) {
        val uri = intent?.data ?: return
        val isVerifiedAppLink =
            uri.scheme == "https" && uri.host == "trueweb24.ru" && uri.path == "/mobile-auth/callback"
        val isAppScheme = uri.scheme == "trueweb" && uri.host == "auth" && uri.path == "/callback"
        if (!isVerifiedAppLink && !isAppScheme) return

        val error = uri.getQueryParameter("error")
        if (!error.isNullOrBlank()) {
            authError = error
            authInProgress = false
            return
        }

        val code = uri.getQueryParameter("code") ?: return
        authInProgress = true
        authError = null

        Thread {
            val result = AuthBackend.exchangeCode(code)
            runOnUiThread {
                authInProgress = false
                result.onSuccess { accessToken ->
                    sessionStore.accessToken = accessToken
                    authenticated = true
                    subscription = null
                    loadProfile(accessToken)
                }.onFailure {
                    authError = "Не удалось завершить вход: ${cleanError(it)}"
                }
            }
        }.start()
    }

    private fun loadProfile(tokenOverride: String? = null) {
        if (profileLoading) return
        val token = tokenOverride ?: sessionStore.accessToken ?: return
        profileLoading = true
        profileError = null
        Thread {
            val result = TrueWebApi.me(token)
            runOnUiThread {
                profileLoading = false
                result.onSuccess {
                    subscription = it
                    profileError = null
                }.onFailure {
                    val message = cleanError(it)
                    if ((it.message ?: "").contains("HTTP 401")) {
                        sessionStore.clear()
                        subscription = null
                        authenticated = false
                        authError = "Сессия истекла. Войдите через Telegram ещё раз."
                    } else {
                        profileError = "Не удалось обновить данные: $message"
                    }
                }
            }
        }.start()
    }

    private fun activateTrial() {
        if (trialLoading) return
        val token = sessionStore.accessToken ?: return
        trialLoading = true
        profileError = null
        Thread {
            val result = TrueWebApi.activateTrial(token)
            runOnUiThread {
                trialLoading = false
                result.onSuccess {
                    subscription = it
                    Toast.makeText(this, "Пробный доступ активирован на 3 дня", Toast.LENGTH_LONG).show()
                }.onFailure {
                    profileError = cleanError(it)
                }
            }
        }.start()
    }

    private fun logout() {
        val token = sessionStore.accessToken
        sessionStore.clear()
        subscription = null
        profileError = null
        authenticated = false
        if (!token.isNullOrBlank()) {
            Thread { TrueWebApi.logout(token) }.start()
        }
    }

    private fun requestVpnPermission() {
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            vpnPermissionLauncher.launch(prepareIntent)
        } else {
            Toast.makeText(
                this,
                "Разрешение уже выдано. VLESS/Reality-движок подключим следующим шагом.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun openExternal(url: String) {
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }.onFailure {
            Toast.makeText(this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show()
        }
    }

    private fun cleanError(t: Throwable): String {
        val raw = t.message ?: "неизвестная ошибка"
        return raw.substringAfter(": ", raw).take(220)
    }
}

@Composable
private fun LoadingScreen(errorText: String?, onRetry: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF07111E), Color(0xFF0A1D2B), Color(0xFF07111E))
                )
            )
            .padding(28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (errorText.isNullOrBlank()) {
                CircularProgressIndicator()
                Spacer(Modifier.height(18.dp))
                Text("Загружаем подписку…", color = MaterialTheme.colorScheme.onBackground)
            } else {
                Text(errorText, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(16.dp))
                Button(onClick = onRetry) { Text("Повторить") }
            }
        }
    }
}

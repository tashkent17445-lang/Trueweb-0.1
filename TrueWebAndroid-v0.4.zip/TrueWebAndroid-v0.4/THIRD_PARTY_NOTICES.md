# Third-party notices

## Xray-core / AndroidLibXrayLite

TrueWeb v0.4 uses AndroidLibXrayLite (`libv2ray.aar`) from 2dust, which wraps XTLS/Xray-core for Android.
The build workflow pins AndroidLibXrayLite release v26.7.31.

Please review the upstream license terms in the respective repositories before distribution.

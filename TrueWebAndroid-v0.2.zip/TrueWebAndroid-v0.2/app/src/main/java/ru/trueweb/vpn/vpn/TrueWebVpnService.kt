package ru.trueweb.vpn.vpn

import android.net.VpnService

/**
 * VPN service shell.
 *
 * IMPORTANT: v0.1 intentionally does NOT establish a TUN interface yet.
 * The VLESS/Reality engine (Xray/libXray or another compatible core) should
 * own the actual packet forwarding. Keeping the shell separate prevents a
 * half-configured build from black-holing the user's traffic.
 */
class TrueWebVpnService : VpnService() {
    override fun onRevoke() {
        stopSelf()
        super.onRevoke()
    }
}

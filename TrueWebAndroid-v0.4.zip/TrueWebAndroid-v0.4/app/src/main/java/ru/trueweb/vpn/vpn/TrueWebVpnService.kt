package ru.trueweb.vpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.util.Base64
import android.util.Log
import androidx.core.app.NotificationCompat
import go.Seq
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import ru.trueweb.vpn.MainActivity
import ru.trueweb.vpn.R
import ru.trueweb.vpn.model.VpnMode
import ru.trueweb.vpn.model.VpnRole
import ru.trueweb.vpn.model.VpnServer
import ru.trueweb.vpn.store.DeviceIdentity
import ru.trueweb.vpn.store.RoutingStore
import ru.trueweb.vpn.store.ServerStore
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.ThreadLocalRandom
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * TrueWeb 0.8 connection policy:
 * - NORMAL: inbound 1 -> inbound 18 only when the current entry is unreachable.
 * - WHITELIST: user starts WL manually; the app never enters WL automatically.
 * - While WL is active, normal entries are re-checked roughly every 3 minutes.
 *   A return to normal happens only after 3 consecutive successful probes.
 * - Physical network changes are tracked separately from the VPN network so a
 *   tunnel reconnects automatically after LTE/Wi-Fi disappears and returns.
 */
class TrueWebVpnService : VpnService() {
    enum class TunnelState { STOPPED, CONNECTING, RUNNING, ERROR }

    companion object {
        const val ACTION_START_NORMAL = "ru.trueweb.vpn.START_NORMAL"
        const val ACTION_START_WHITELIST = "ru.trueweb.vpn.START_WHITELIST"
        const val ACTION_STOP = "ru.trueweb.vpn.STOP"
        const val ACTION_FOREGROUND_CHECK = "ru.trueweb.vpn.FOREGROUND_CHECK"

        private const val CHANNEL_ID = "trueweb_vpn"
        private const val NOTIFICATION_ID = 1001
        private const val TAG = "TrueWebXray"

        private const val TCP_PROBE_TIMEOUT_MS = 2500
        private const val NORMAL_HEALTH_SECONDS = 60L
        private const val WL_RECOVERY_MIN_SECONDS = 170L
        private const val WL_RECOVERY_MAX_SECONDS = 211L
        private const val STABLE_PROBE_COUNT = 3
        private const val STABLE_PROBE_GAP_MS = 4000L

        private val _state = MutableStateFlow(TunnelState.STOPPED)
        val state: StateFlow<TunnelState> = _state

        private val _lastError = MutableStateFlow<String?>(null)
        val lastError: StateFlow<String?> = _lastError

        private val _mode = MutableStateFlow(VpnMode.NORMAL)
        val mode: StateFlow<VpnMode> = _mode

        private val _activeRole = MutableStateFlow(VpnRole.UNKNOWN)
        val activeRole: StateFlow<VpnRole> = _activeRole

        private val _whitelistSuggested = MutableStateFlow(false)
        val whitelistSuggested: StateFlow<Boolean> = _whitelistSuggested

        fun startNormal(context: Context) {
            context.startForegroundService(
                Intent(context, TrueWebVpnService::class.java).setAction(ACTION_START_NORMAL)
            )
        }

        fun startWhitelist(context: Context) {
            context.startForegroundService(
                Intent(context, TrueWebVpnService::class.java).setAction(ACTION_START_WHITELIST)
            )
        }

        fun stop(context: Context) {
            context.startService(Intent(context, TrueWebVpnService::class.java).setAction(ACTION_STOP))
        }

        fun foregroundCheck(context: Context) {
            context.startService(
                Intent(context, TrueWebVpnService::class.java).setAction(ACTION_FOREGROUND_CHECK)
            )
        }
    }

    private val starting = AtomicBoolean(false)
    private val store by lazy { ServerStore(applicationContext) }
    private val routingStore by lazy { RoutingStore(applicationContext) }
    private val connectivity by lazy { getSystemService(ConnectivityManager::class.java) }
    private val scheduler = Executors.newSingleThreadScheduledExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var tunFd: ParcelFileDescriptor? = null
    private var core: CoreController? = null
    private var normalHealthFuture: ScheduledFuture<*>? = null
    private var whitelistRecoveryFuture: ScheduledFuture<*>? = null

    @Volatile
    private var physicalNetwork: Network? = null

    private val reconnectRunnable = Runnable {
        if (store.desiredRunning) startTunnelAsync()
    }

    private val callback = object : CoreCallbackHandler {
        override fun startup(): Long {
            Log.i(TAG, "Xray callback: startup")
            return 0
        }

        override fun shutdown(): Long {
            Log.i(TAG, "Xray callback: shutdown")
            return 0
        }

        override fun onEmitStatus(code: Long, message: String?): Long {
            Log.i(TAG, "Xray status $code: ${message.orEmpty()}")
            return 0
        }
    }

    private val physicalNetworkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            physicalNetwork = network
            runCatching { setUnderlyingNetworks(arrayOf(network)) }
            if (store.desiredRunning) {
                Log.i(TAG, "Physical network available: $network")
                mainHandler.removeCallbacks(reconnectRunnable)
                mainHandler.postDelayed(reconnectRunnable, 1200L)
            }
        }

        override fun onLost(network: Network) {
            if (physicalNetwork == network) physicalNetwork = findPhysicalNetwork(exclude = network)
            if (!store.desiredRunning) return

            Log.i(TAG, "Physical network lost: $network")
            cancelHealthSchedules()
            Thread {
                stopCoreOnly()
                store.activeRole = VpnRole.UNKNOWN
                _activeRole.value = VpnRole.UNKNOWN
                _state.value = TunnelState.CONNECTING
                _lastError.value = null
                updateNotification("Ждём сеть…")
            }.start()

            physicalNetwork?.let {
                mainHandler.removeCallbacks(reconnectRunnable)
                mainHandler.postDelayed(reconnectRunnable, 1200L)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        initializeCore()
        registerPhysicalNetworkCallback()
        _mode.value = store.desiredMode
        _activeRole.value = store.activeRole
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                store.desiredRunning = false
                store.activeRole = VpnRole.UNKNOWN
                cancelHealthSchedules()
                mainHandler.removeCallbacks(reconnectRunnable)
                stopTunnel(clearError = true)
                _mode.value = VpnMode.NORMAL
                _activeRole.value = VpnRole.UNKNOWN
                _whitelistSuggested.value = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }

            ACTION_START_NORMAL -> {
                store.desiredRunning = true
                store.desiredMode = VpnMode.NORMAL
                _mode.value = VpnMode.NORMAL
                _whitelistSuggested.value = false
                startForeground(NOTIFICATION_ID, notification("Подключение…"))
                startTunnelAsync()
            }

            ACTION_START_WHITELIST -> {
                store.desiredRunning = true
                store.desiredMode = VpnMode.WHITELIST
                _mode.value = VpnMode.WHITELIST
                _whitelistSuggested.value = false
                startForeground(NOTIFICATION_ID, notification("Белые списки: подключение…"))
                startTunnelAsync()
            }

            ACTION_FOREGROUND_CHECK -> {
                if (store.desiredRunning && store.desiredMode == VpnMode.NORMAL) {
                    Thread { normalHealthCheck(foreground = true) }.start()
                }
            }

            else -> {
                if (!store.desiredRunning) return START_NOT_STICKY
                _mode.value = store.desiredMode
                startForeground(NOTIFICATION_ID, notification("Восстанавливаем подключение…"))
                startTunnelAsync()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        cancelHealthSchedules()
        mainHandler.removeCallbacks(reconnectRunnable)
        runCatching { connectivity.unregisterNetworkCallback(physicalNetworkCallback) }
        scheduler.shutdownNow()
        stopTunnel(clearError = false)
        super.onDestroy()
    }

    override fun onRevoke() {
        store.desiredRunning = false
        store.activeRole = VpnRole.UNKNOWN
        cancelHealthSchedules()
        stopTunnel(clearError = true)
        stopSelf()
        super.onRevoke()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (store.desiredRunning) updateNotification("TrueWeb работает в фоне")
        super.onTaskRemoved(rootIntent)
    }

    private fun registerPhysicalNetworkCallback() {
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        runCatching { connectivity.registerNetworkCallback(request, physicalNetworkCallback) }
            .onFailure { Log.w(TAG, "Network callback registration failed", it) }
        physicalNetwork = findPhysicalNetwork()
    }

    private fun findPhysicalNetwork(exclude: Network? = null): Network? {
        return runCatching {
            connectivity.allNetworks.firstOrNull { network ->
                if (network == exclude) return@firstOrNull false
                val caps = connectivity.getNetworkCapabilities(network) ?: return@firstOrNull false
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            }
        }.getOrNull()
    }

    @Synchronized
    private fun initializeCore() {
        if (core != null) return
        Seq.setContext(applicationContext)
        ensureGeoAssets()
        val base = filesDir.absolutePath
        val hwid = DeviceIdentity(this).hwid
        val keyBytes = MessageDigest.getInstance("SHA-256")
            .digest(hwid.toByteArray(Charsets.UTF_8))
        val xudpBaseKey = Base64.encodeToString(
            keyBytes,
            Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
        )
        Libv2ray.initCoreEnv(base, xudpBaseKey)
        core = Libv2ray.newCoreController(callback)
        Log.i(TAG, "${Libv2ray.checkVersionX()}")
    }

    private fun startTunnelAsync(target: VpnServer? = null) {
        if (!starting.compareAndSet(false, true)) return
        Thread {
            try {
                cancelHealthSchedules()
                _lastError.value = null
                _state.value = TunnelState.CONNECTING
                val mode = store.desiredMode
                _mode.value = mode
                updateNotification(if (mode == VpnMode.WHITELIST) "Белые списки: подключение…" else "Подключение…")

                val network = physicalNetwork ?: findPhysicalNetwork().also { physicalNetwork = it }
                if (network == null) {
                    stopCoreOnly()
                    store.activeRole = VpnRole.UNKNOWN
                    _activeRole.value = VpnRole.UNKNOWN
                    _state.value = TunnelState.CONNECTING
                    updateNotification("Ждём сеть…")
                    return@Thread
                }
                runCatching { setUnderlyingNetworks(arrayOf(network)) }

                val selected = target ?: when (mode) {
                    VpnMode.NORMAL -> chooseNormalServer()
                    VpnMode.WHITELIST -> chooseWhitelistServer()
                }

                if (selected == null) {
                    if (mode == VpnMode.NORMAL) {
                        markNormalUnavailable()
                    } else {
                        stopCoreOnly()
                        store.activeRole = VpnRole.UNKNOWN
                        _activeRole.value = VpnRole.UNKNOWN
                        _lastError.value = "Белые списки сейчас недоступны"
                        _state.value = TunnelState.ERROR
                        updateNotification("Белые списки недоступны")
                    }
                    return@Thread
                }

                initializeCore()
                stopCoreOnly()

                val routingPolicy = routingStore.load()
                val built = XrayConfigBuilder.build(
                    server = selected,
                    smartAuto = routingPolicy.smartAuto,
                    bypassRu = routingPolicy.bypassRu
                )
                tunFd = establishVpnInterface()

                val controller = core ?: error("Xray-core не инициализирован")
                controller.startLoop(built.json, tunFd!!.fd)
                if (!controller.isRunning) error("Xray-core не запустился")

                store.activeRole = selected.role
                _activeRole.value = selected.role
                _state.value = TunnelState.RUNNING
                _lastError.value = null
                _whitelistSuggested.value = false
                updateNotification(if (mode == VpnMode.WHITELIST) "Белые списки активны" else "VPN подключён")
                Log.i(TAG, "Tunnel started mode=$mode role=${selected.role} inbound=${selected.inboundId}")

                if (mode == VpnMode.WHITELIST) scheduleWhitelistRecovery()
                else scheduleNormalHealth()
            } catch (e: Throwable) {
                Log.e(TAG, "Start failed: ${e.message}", e)
                _lastError.value = friendlyError(e)
                _state.value = TunnelState.ERROR
                updateNotification("Ошибка VPN: ${friendlyError(e).take(90)}")
                stopCoreOnly()
                if (store.desiredMode == VpnMode.NORMAL) {
                    _whitelistSuggested.value = probeWhitelistAvailable()
                    scheduleNormalHealth()
                } else {
                    scheduleWhitelistRecovery()
                }
            } finally {
                starting.set(false)
            }
        }.start()
    }

    private fun chooseNormalServer(): VpnServer? {
        val primary = store.primaryServer()
        if (primary != null && probeReachable(primary)) return primary
        val backup = store.backupServer()
        if (backup != null && probeReachable(backup)) return backup
        return null
    }

    private fun chooseWhitelistServer(): VpnServer? =
        store.whitelistServers().firstOrNull { probeReachable(it) }

    private fun normalHealthCheck(foreground: Boolean = false) {
        if (!store.desiredRunning || store.desiredMode != VpnMode.NORMAL || starting.get()) return
        if ((physicalNetwork ?: findPhysicalNetwork()) == null) return

        if (_state.value != TunnelState.RUNNING) {
            startTunnelAsync()
            return
        }

        val role = store.activeRole
        val active = store.serverForRole(role)
        if (active != null && probeReachable(active)) {
            _whitelistSuggested.value = false
            return
        }

        // One confirmation avoids switching on a single short radio hiccup.
        if (!foreground) {
            Thread.sleep(2500L)
            if (active != null && probeReachable(active)) {
                _whitelistSuggested.value = false
                return
            }
        }

        val alternate = when (role) {
            VpnRole.PRIMARY -> store.backupServer()
            VpnRole.BACKUP -> store.primaryServer()
            else -> store.primaryServer() ?: store.backupServer()
        }
        if (alternate != null && probeReachable(alternate)) {
            Log.i(TAG, "Normal failover ${role.name} -> ${alternate.role.name}")
            startTunnelAsync(alternate)
            return
        }

        // If the active role was unknown, make sure both ordinary entries were tried.
        if (role == VpnRole.UNKNOWN) {
            val secondary = store.backupServer()
            if (secondary != null && secondary.id != alternate?.id && probeReachable(secondary)) {
                startTunnelAsync(secondary)
                return
            }
        }

        markNormalUnavailable()
    }

    private fun markNormalUnavailable() {
        stopCoreOnly()
        store.activeRole = VpnRole.UNKNOWN
        _activeRole.value = VpnRole.UNKNOWN
        _lastError.value = "Обычное подключение сейчас недоступно"
        _state.value = TunnelState.ERROR
        _whitelistSuggested.value = probeWhitelistAvailable()
        updateNotification("Обычное подключение недоступно")
        scheduleNormalHealth()
    }

    private fun probeWhitelistAvailable(): Boolean =
        store.whitelistServers().any { probeReachable(it) }

    private fun scheduleNormalHealth(delaySeconds: Long = NORMAL_HEALTH_SECONDS) {
        normalHealthFuture?.cancel(false)
        whitelistRecoveryFuture?.cancel(false)
        if (!store.desiredRunning || store.desiredMode != VpnMode.NORMAL) return
        normalHealthFuture = scheduler.schedule({
            try {
                normalHealthCheck(foreground = false)
            } catch (e: Throwable) {
                Log.w(TAG, "Normal health check failed", e)
            } finally {
                if (store.desiredRunning && store.desiredMode == VpnMode.NORMAL) {
                    scheduleNormalHealth()
                }
            }
        }, delaySeconds, TimeUnit.SECONDS)
    }

    private fun scheduleWhitelistRecovery() {
        whitelistRecoveryFuture?.cancel(false)
        normalHealthFuture?.cancel(false)
        if (!store.desiredRunning || store.desiredMode != VpnMode.WHITELIST) return
        val delay = ThreadLocalRandom.current().nextLong(
            WL_RECOVERY_MIN_SECONDS,
            WL_RECOVERY_MAX_SECONDS
        )
        whitelistRecoveryFuture = scheduler.schedule({
            try {
                whitelistRecoveryCheck()
            } catch (e: Throwable) {
                Log.w(TAG, "Whitelist recovery check failed", e)
            } finally {
                if (store.desiredRunning && store.desiredMode == VpnMode.WHITELIST) {
                    scheduleWhitelistRecovery()
                }
            }
        }, delay, TimeUnit.SECONDS)
    }

    private fun whitelistRecoveryCheck() {
        if (!store.desiredRunning || store.desiredMode != VpnMode.WHITELIST || starting.get()) return
        if ((physicalNetwork ?: findPhysicalNetwork()) == null) return

        val primary = store.primaryServer()
        if (primary != null && stableReachable(primary)) {
            switchWhitelistToNormal(primary)
            return
        }

        val backup = store.backupServer()
        if (backup != null && stableReachable(backup)) {
            switchWhitelistToNormal(backup)
            return
        }

        // Normal access is still closed. Stay on WL. If the current WL entry itself
        // died and another WL entry exists, fail over only inside the WL pool.
        val activeWl = if (store.activeRole == VpnRole.WHITELIST) {
            store.whitelistServers().firstOrNull { it.id == store.serverForRole(VpnRole.WHITELIST)?.id }
        } else null
        if (activeWl != null && probeReachable(activeWl)) return

        val replacement = store.whitelistServers().firstOrNull { probeReachable(it) }
        if (replacement != null) startTunnelAsync(replacement)
    }

    private fun switchWhitelistToNormal(server: VpnServer) {
        Log.i(TAG, "Ordinary access is stable again; leaving WL via ${server.role}")
        store.desiredMode = VpnMode.NORMAL
        _mode.value = VpnMode.NORMAL
        _whitelistSuggested.value = false
        startTunnelAsync(server)
    }

    private fun stableReachable(server: VpnServer): Boolean {
        repeat(STABLE_PROBE_COUNT) { index ->
            if (!probeReachable(server)) return false
            if (index < STABLE_PROBE_COUNT - 1) Thread.sleep(STABLE_PROBE_GAP_MS)
        }
        return true
    }

    private fun probeReachable(server: VpnServer): Boolean {
        val raw = server.uri ?: return false
        val uri = runCatching { Uri.parse(raw) }.getOrNull() ?: return false
        val host = uri.host?.takeIf { it.isNotBlank() } ?: return false
        val port = uri.port.takeIf { it > 0 } ?: 443
        val network = physicalNetwork ?: findPhysicalNetwork().also { physicalNetwork = it }

        return runCatching {
            val socket: Socket = network?.socketFactory?.createSocket() ?: Socket()
            socket.use { it.connect(InetSocketAddress(host, port), TCP_PROBE_TIMEOUT_MS) }
            true
        }.getOrElse {
            Log.d(TAG, "Probe failed role=${server.role} inbound=${server.inboundId} $host:$port: ${it.message}")
            false
        }
    }

    private fun friendlyError(e: Throwable): String {
        val raw = (e.message ?: e.javaClass.simpleName).replace('\n', ' ').trim()
        return when {
            raw.contains("xhttp", ignoreCase = true) -> "XHTTP: $raw"
            raw.contains("reality", ignoreCase = true) -> "REALITY: $raw"
            raw.contains("config", ignoreCase = true) -> "Конфигурация Xray: $raw"
            else -> raw
        }.take(300)
    }

    private fun establishVpnInterface(): ParcelFileDescriptor {
        val builder = Builder()
            .setSession("TrueWeb")
            .setMtu(1500)
            .addAddress("172.16.0.2", 30)
            .addRoute("0.0.0.0", 0)
            .addAddress("fdfe:dcba:9876::2", 126)
            .addRoute("::", 0)
            .addDnsServer("77.88.8.8")
            .addDnsServer("1.1.1.1")

        // Xray belongs to this app UID; excluding our own process keeps its outbound
        // sockets and health probes on the physical network and avoids a VPN loop.
        runCatching { builder.addDisallowedApplication(packageName) }

        // Russian apps are excluded at Android VpnService level in every TrueWeb mode,
        // including WL. They never enter the tunnel and therefore do not see a VPN IP.
        val policy = routingStore.load()
        if (policy.smartAuto) {
            policy.excludedPackages.forEach { pkg ->
                if (pkg != packageName) {
                    runCatching { builder.addDisallowedApplication(pkg) }
                        .onFailure { Log.d(TAG, "Bypass app not installed or unavailable: $pkg") }
                }
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) builder.setMetered(false)
        physicalNetwork?.let { runCatching { setUnderlyingNetworks(arrayOf(it)) } }
        return builder.establish() ?: error("Android не создал VPN-интерфейс")
    }

    private fun ensureGeoAssets() {
        listOf("geoip.dat", "geosite.dat").forEach { name ->
            val target = File(filesDir, name)
            val tmp = File(filesDir, "$name.tmp")
            assets.open(name).use { input ->
                tmp.outputStream().use { output -> input.copyTo(output) }
            }
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) {
                tmp.copyTo(target, overwrite = true)
                tmp.delete()
            }
        }
    }

    @Synchronized
    private fun stopCoreOnly() {
        runCatching {
            val controller = core
            if (controller != null && controller.isRunning) controller.stopLoop()
        }.onFailure { Log.w(TAG, "Xray stop failed", it) }
        runCatching { tunFd?.close() }
        tunFd = null
    }

    private fun stopTunnel(clearError: Boolean) {
        stopCoreOnly()
        if (clearError) _lastError.value = null
        _state.value = TunnelState.STOPPED
    }

    private fun cancelHealthSchedules() {
        normalHealthFuture?.cancel(false)
        whitelistRecoveryFuture?.cancel(false)
        normalHealthFuture = null
        whitelistRecoveryFuture = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "TrueWeb VPN", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Подключение TrueWeb VPN"
                    setShowBadge(false)
                }
            )
        }
    }

    private fun notification(text: String): Notification {
        val pending = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("TrueWeb")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_trueweb)
            .setContentIntent(pending)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
    }
}

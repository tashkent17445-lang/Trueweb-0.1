# TrueWeb Android 0.7.0

Standalone TrueWeb Android client with Telegram login, Xray/XHTTP/Reality, subscription management and YooKassa payments.

## Smart Auto

When **Автовыбор** is selected:
- private/local networks go direct;
- Russian domains (`geosite:category-ru`, `.ru`, `.su`, `.рф`) go direct;
- Russian IP ranges (`geoip:ru`) go direct;
- selected Russian apps are excluded from Android VpnService entirely;
- all remaining traffic uses the existing Xray `leastPing` balancer.

When a specific server is selected, TrueWeb uses full-tunnel routing through that server.

The excluded-app list is fetched from `/api/mobile/routing` and cached for 6 hours. A local fallback list is bundled in the APK.

## Release signing

0.7.0 is designed to be built as a signed **release APK**. Keep one permanent signing key. Future APKs signed by that key can be installed over the previous version without uninstalling the app.

The workflow expects GitHub Secrets:
- `TW_KEYSTORE_BASE64`
- `TW_KEYSTORE_PASSWORD`
- `TW_KEY_ALIAS`
- `TW_KEY_PASSWORD`

Never commit the keystore or these values to the public repository.

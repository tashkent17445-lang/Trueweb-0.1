# TrueWeb Android 0.8.6

Changes from 0.8.4:

- Disconnected VPN button now uses the same live/pulsing animation in red; active tunnel remains green.
- VPN takeover is requested before profile refresh. If Happ/Incy/another Android VPN owns the VPN slot, Android can transfer the slot to TrueWeb after user confirmation.
- When another VPN revokes TrueWeb, the UI reports that TrueWeb was disabled by another VPN application instead of treating it as a generic crash.
- Battery/Doze guidance: TrueWeb detects Android battery optimization, shows a one-time hint, and offers a system button to allow unrestricted background operation. No permanent WakeLock is used.
- GeoData (`geoip.dat` / `geosite.dat`) keeps bundled files as an offline fallback and checks for a fresh copy approximately every 72 hours using WorkManager.
- GeoData sources:
  - https://github.com/v2fly/geoip/releases/latest/download/geoip.dat
  - https://github.com/v2fly/domain-list-community/releases/latest/download/dlc.dat (saved as `geosite.dat`)
- GeoData downloads are staged and only replace the working pair after both downloads validate; a failed GitHub request leaves the old databases intact.
- Settings show GeoData last-update time and include a manual refresh action.
- Account deletion warning explicitly states that subscriptions/payment-derived access cannot be restored and deleting/re-registering does not reset the one-time trial.

Upgrade compatibility:

- applicationId stays `ru.trueweb.vpn`.
- versionCode: 15
- versionName: 0.8.6
- Installing a release APK signed with the same release certificate over 0.8.4 performs a normal Android update and preserves app data/session/settings. Do not uninstall the old app first.

## Обновление приложения

- TrueWeb сам проверяет `https://trueweb24.ru:8443/android/latest.json`.
- При наличии новой версии показывает диалог «Обновить / Позже».
- APK скачивается внутри приложения, проверяется по SHA-256 и передаётся стандартному установщику Android.
- На Android 8+ при первой установке обновления пользователь один раз разрешает TrueWeb установку из этого источника.
- Аккаунт, подписка и настройки при обновлении сохраняются, если APK подписан тем же release-ключом.

### Важно для перехода с 0.8.4
Версия 0.8.4 ещё не содержит встроенный updater, поэтому переход 0.8.4 → 0.8.6 выполняется обычной установкой APK поверх старой версии. Начиная с 0.8.6 следующие обновления можно устанавливать из самого TrueWeb.


## Интерфейс 0.8.6

- Главный экран Android повторяет удобные быстрые кнопки Windows: Настройки, Обновить и Выйти сверху.
- Под карточкой подписки добавлены две быстрые кнопки: Группа и Поддержка.
- Поддержка открывает https://t.me/TrueWebHelp, группа — https://t.me/proxi_vpn_bs.
- Эти же ссылки доступны в настройках.

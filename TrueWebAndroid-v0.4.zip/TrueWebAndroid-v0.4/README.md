# TrueWeb Android 0.8.1

TrueWeb 0.8 simplifies the mobile connection model.

## Connection policy

- **Primary**: 3x-ui inbound ID **1**.
- **Backup**: 3x-ui inbound ID **18**. It is used only when the primary entry is unreachable.
- **WL / Белые списки**: a separate manual mode. The mobile API marks an inbound with role `wl`; the app never switches into WL automatically.
- While WL is active, TrueWeb checks normal entries roughly every 170–210 seconds. A normal entry must pass **3 consecutive TCP reachability probes** before the app leaves WL automatically.
- The client connects to only one VLESS inbound at a time. Server-side Xray/3x-ui keeps the real routing and balancing behind that inbound.

## Road / network recovery

The VPN service watches the Android physical network with `NET_CAPABILITY_NOT_VPN`. If LTE/Wi-Fi disappears and later returns, TrueWeb rebuilds the tunnel automatically instead of leaving a dead VPN interface until the user reconnects manually.

## Russian app bypass

The existing `/api/mobile/routing` policy remains. Packages in `excluded_packages` are added with `VpnService.Builder.addDisallowedApplication`, so those apps bypass the VPN at Android level. The same rule is applied in normal and WL modes.

## Mobile API contract

`GET /api/mobile/servers` must return only production entries that the APK is allowed to use. Each server row should include:

```json
{
  "id": "inbound_1",
  "name": "TrueWeb",
  "protocol": "vless",
  "uri": "vless://...",
  "available": true,
  "role": "primary",
  "inbound_id": 1
}
```

Roles:

- `primary` -> inbound 1
- `backup` -> inbound 18
- `wl` -> an explicitly published WL inbound

Test inbounds must not be returned by this API.

## UI

- Server selection is removed from the home screen.
- All green UI accents and action buttons use the single brand green `#309326`.
- `Белые списки` lives under the main connect control.
- If normal entries are unavailable but WL is reachable, the WL button gets a pulsing red gradient border.
- While WL is active, that button is highlighted green.

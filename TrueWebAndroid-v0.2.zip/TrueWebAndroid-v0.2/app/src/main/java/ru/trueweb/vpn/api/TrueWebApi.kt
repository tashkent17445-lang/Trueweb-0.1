package ru.trueweb.vpn.api

import org.json.JSONObject
import ru.trueweb.vpn.AppConfig
import ru.trueweb.vpn.model.SubscriptionInfo
import java.net.HttpURLConnection
import java.net.URL

object TrueWebApi {
    fun exchangeCode(code: String): Result<String> = runCatching {
        val json = request(
            method = "POST",
            path = "/auth/exchange",
            body = JSONObject().put("code", code).toString()
        )
        json.getString("access_token")
    }

    fun me(accessToken: String): Result<SubscriptionInfo> = runCatching {
        SubscriptionInfo.fromApi(request("GET", "/me", accessToken = accessToken))
    }

    fun activateTrial(accessToken: String): Result<SubscriptionInfo> = runCatching {
        SubscriptionInfo.fromApi(request("POST", "/trial", accessToken = accessToken, body = "{}"))
    }

    fun logout(accessToken: String): Result<Unit> = runCatching {
        request("POST", "/logout", accessToken = accessToken, body = "{}")
        Unit
    }

    private fun request(
        method: String,
        path: String,
        accessToken: String? = null,
        body: String? = null
    ): JSONObject {
        val connection = URL("${AppConfig.API_BASE}$path").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            connection.connectTimeout = 12_000
            connection.readTimeout = 15_000
            connection.setRequestProperty("Accept", "application/json")
            if (!accessToken.isNullOrBlank()) {
                connection.setRequestProperty("Authorization", "Bearer $accessToken")
            }
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }

            val responseCode = connection.responseCode
            val stream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val json = if (text.isBlank()) JSONObject() else runCatching { JSONObject(text) }.getOrElse {
                JSONObject().put("error", text.take(500))
            }

            if (responseCode !in 200..299) {
                val message = json.optString("error", "HTTP $responseCode")
                error("HTTP $responseCode: $message")
            }
            return json
        } finally {
            connection.disconnect()
        }
    }
}

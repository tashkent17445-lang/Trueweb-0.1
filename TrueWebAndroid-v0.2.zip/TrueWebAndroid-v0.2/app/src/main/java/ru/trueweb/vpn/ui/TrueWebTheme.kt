package ru.trueweb.vpn.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TrueWebColors = darkColorScheme(
    primary = Color(0xFF38D39F),
    onPrimary = Color(0xFF002117),
    secondary = Color(0xFF79E8C2),
    background = Color(0xFF07111E),
    surface = Color(0xFF0D1B2A),
    surfaceVariant = Color(0xFF13263A),
    onBackground = Color(0xFFF3F7FA),
    onSurface = Color(0xFFF3F7FA),
    onSurfaceVariant = Color(0xFFB7C5D1)
)

@Composable
fun TrueWebTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = TrueWebColors, content = content)
}

# TrueWeb Android 0.8.3

TrueWeb 0.8.3 keeps the existing VPN core and adds email login plus the finalized connection-button UI.

## Authentication

- Telegram login remains available.
- Email login is independent from Telegram: the user receives a 6-digit code and can enter the app immediately after verification.
- A brand-new email identity gets the normal 3-day trial immediately, so Telegram is not required to obtain the first VPN connection.
- After VPN is available, an unlinked email account can attach Telegram from inside the app.
- If that Telegram identity already exists in TrueWeb, the existing Telegram account remains authoritative and the temporary email VPN client is removed after the merge.
- If the Telegram identity is new, the email trial is carried to the new Telegram profile and the temporary client is removed.
- Once linked, future email logins go directly to the same account and no longer ask to link Telegram again.

Backend endpoints used by this APK:

- `POST /api/mobile/auth/email/start`
- `POST /api/mobile/auth/email/verify`
- `POST /api/mobile/auth/email/link-telegram`

The backend sends codes through SMTP configured only with environment variables. The default sender address is `auth@trueweb24.ru`; no SMTP password is stored in the APK or in `bot.py`.

## Connection policy

- **Primary**: 3x-ui inbound ID **1**.
- **Backup**: 3x-ui inbound ID **18**. It is used only when the primary entry is unreachable.
- **WL / Белые списки**: a separate manual mode. The app never switches into WL automatically.
- WL cannot be started while the ordinary TrueWeb entries are reachable. It becomes available only after the primary and backup paths are unavailable and the WL endpoint itself is reachable.
- While WL is active, TrueWeb checks normal entries roughly every 170–210 seconds. A normal entry must pass **3 consecutive TCP reachability probes** before the app leaves WL automatically.
- The client connects to one VLESS inbound at a time. Server-side Xray/3x-ui continues to handle the actual routing and balancing.

## Main connect button

- VPN off: black button with a **red globe**.
- VPN on / connecting: **white globe**.
- Active button background uses a slow living radial gradient from the TrueWeb green `#309326` toward almost black, with darker edges and a subtle moving highlight.
- Color changes are animated instead of snapping instantly.

## UI

- No server/location selector is shown to the user.
- The separate “Локации” control is not present.
- `Белые списки` stays directly under the main connect button.
- If normal entries are unavailable but WL is reachable, the WL control gets the existing pulsing red indication.
- While WL is active, its control uses the TrueWeb green.
- The launcher icon uses the supplied TrueWeb artwork and Android adaptive-icon resources.

## Road / network recovery

The VPN service watches Android physical networks with `NET_CAPABILITY_NOT_VPN` through `NetworkCallback`. If LTE/Wi-Fi disappears and later returns, TrueWeb rebuilds the tunnel automatically. Losing an unrelated secondary physical network does not tear down the active tunnel.

## Russian app bypass

The existing `/api/mobile/routing` policy remains. Packages in `excluded_packages` are added with `VpnService.Builder.addDisallowedApplication`, so those apps bypass the VPN at Android level. The same rule is applied in normal and WL modes.

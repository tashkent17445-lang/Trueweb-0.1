# Third-party notices

TrueWeb Android v0.3 embeds sing-box `libbox` 1.13.14 at build time.

- Project: sing-box / libbox
- Artifact source: `singbox-android/libbox`, version 1.13.14
- License: GNU General Public License v3.0 (GPL-3.0)
- Build artifact URL used by CI: `https://jitpack.io/com/github/singbox-android/libbox/1.13.14/libbox-1.13.14.aar`
- Expected SHA-256: `D8EE7620047E4485199A9CF8DB30E67D1497534117F1774A93C0696068B7B012`

TrueWeb source code and build instructions should remain available alongside distributed APKs as required by the applicable licenses.

#!/usr/bin/env python3
from __future__ import annotations

import ast
import py_compile
import shutil
import sys
from datetime import datetime
from pathlib import Path

BOT_PATH = Path(sys.argv[1] if len(sys.argv) > 1 else "/opt/vpn-bot/bot.py")
MARKER = "# === TRUEWEB MARKET PATCH v0.8.4 ==="


def replace_once(text: str, old: str, new: str, label: str) -> str:
    if old not in text:
        raise SystemExit(f"Не найден якорь {label} — патч остановлен без изменений")
    return text.replace(old, new, 1)


def main():
    if not BOT_PATH.exists():
        raise SystemExit(f"Не найден файл: {BOT_PATH}")
    text = BOT_PATH.read_text(encoding="utf-8")
    if MARKER in text:
        print("v0.8.4 market patch уже применён — изменений нет")
        return
    if "# === TRUEWEB EMAIL AUTH PATCH v0.8.3 ===" not in text:
        raise SystemExit("Сначала должен быть применён email patch v0.8.3")

    config_anchor = 'MOBILE_EMAIL_CODE_SECRET = os.getenv("MOBILE_EMAIL_CODE_SECRET", "").strip() or BOT_TOKEN\n'
    config_block = '''MOBILE_EMAIL_CODE_SECRET = os.getenv("MOBILE_EMAIL_CODE_SECRET", "").strip() or BOT_TOKEN

# === TRUEWEB MARKET PATCH v0.8.4 ===
MOBILE_ACCOUNT_HMAC_SECRET = os.getenv("MOBILE_ACCOUNT_HMAC_SECRET", "").strip() or MOBILE_EMAIL_CODE_SECRET
MOBILE_PASSWORD_MIN_LENGTH = max(8, int(os.getenv("MOBILE_PASSWORD_MIN_LENGTH", "8")))
MOBILE_PASSWORD_MAX_FAILURES = max(3, int(os.getenv("MOBILE_PASSWORD_MAX_FAILURES", "8")))
MOBILE_PASSWORD_FAILURE_WINDOW = max(60, int(os.getenv("MOBILE_PASSWORD_FAILURE_WINDOW", "900")))
MOBILE_ERROR_REPORT_COOLDOWN = max(60, int(os.getenv("MOBILE_ERROR_REPORT_COOLDOWN", "600")))
_mobile_password_failures = {}
_mobile_error_report_seen = {}
'''
    text = replace_once(text, config_anchor, config_block, "market config")

    trial_claim_old = r'''def trial_already_claimed(tg_id):
    con = sqlite3.connect(PAYMENT_DB, timeout=5)
    row = con.execute("SELECT 1 FROM trial_claims WHERE tg_id=?", (int(tg_id),)).fetchone()
    con.close()
    return row is not None
'''
    trial_claim_new = r'''def trial_already_claimed(tg_id):
    con = sqlite3.connect(PAYMENT_DB, timeout=5)
    row = con.execute("SELECT 1 FROM trial_claims WHERE tg_id=?", (int(tg_id),)).fetchone()
    con.close()
    if row is not None:
        return True
    # A deleted/recreated account must not regain the one-time trial.
    try:
        return mobile_trial_identity_seen("tg", int(tg_id))
    except NameError:
        return False
'''
    text = replace_once(text, trial_claim_old, trial_claim_new, "trial tombstone lookup")

    core_anchor = '''async def mobile_auth_email_start_handler(request):
'''
    core = r'''
def _mobile_account_fingerprint(kind, value):
    raw = (str(kind).strip().lower() + "\n" + str(value).strip().lower()).encode("utf-8")
    return hmac.new(MOBILE_ACCOUNT_HMAC_SECRET.encode("utf-8"), raw, hashlib.sha256).hexdigest()


def mobile_trial_identity_seen(kind, value):
    fp = _mobile_account_fingerprint(kind, value)
    con = sqlite3.connect(USER_DB, timeout=5)
    row = con.execute(
        "SELECT 1 FROM mobile_trial_identity_hashes WHERE identity_hash=?",
        (fp,)
    ).fetchone()
    con.close()
    return bool(row)


def mobile_remember_trial_identity(kind, value):
    fp = _mobile_account_fingerprint(kind, value)
    con = sqlite3.connect(USER_DB, timeout=5)
    con.execute(
        "INSERT OR IGNORE INTO mobile_trial_identity_hashes(identity_hash,created_at) VALUES (?,?)",
        (fp, int(time.time()))
    )
    con.commit()
    con.close()


def _mobile_normalize_login(value):
    login = str(value or "").strip().lower()
    if len(login) < 3 or len(login) > 64:
        return ""
    if not re.fullmatch(r"[a-z0-9._@-]+", login):
        return ""
    return login


def _mobile_password_hash(password, salt):
    return hashlib.scrypt(
        str(password).encode("utf-8"),
        salt=salt,
        n=1 << 14,
        r=8,
        p=1,
        dklen=32,
    )


def mobile_set_password_credentials(subject_id, raw_login, raw_password):
    login = _mobile_normalize_login(raw_login)
    password = str(raw_password or "")
    if not login:
        raise ValueError("Логин: 3–64 символа, латинские буквы, цифры, точка, _ или -")
    if len(password) < MOBILE_PASSWORD_MIN_LENGTH or len(password) > 128:
        raise ValueError(f"Пароль должен содержать от {MOBILE_PASSWORD_MIN_LENGTH} до 128 символов")
    if not get_client(int(subject_id)):
        raise RuntimeError("VPN-клиент не найден")

    salt = secrets.token_bytes(16)
    digest = _mobile_password_hash(password, salt)
    now = int(time.time())
    con = sqlite3.connect(USER_DB, timeout=5)
    try:
        con.execute("BEGIN IMMEDIATE")
        owner = con.execute(
            "SELECT subject_id FROM mobile_password_credentials WHERE login=?",
            (login,)
        ).fetchone()
        if owner and int(owner[0]) != int(subject_id):
            con.rollback()
            raise ValueError("Этот логин уже занят")
        con.execute("DELETE FROM mobile_password_credentials WHERE subject_id=?", (int(subject_id),))
        con.execute(
            """INSERT INTO mobile_password_credentials(login,subject_id,salt,password_hash,updated_at)
               VALUES (?,?,?,?,?)""",
            (login, int(subject_id), salt.hex(), digest.hex(), now)
        )
        con.commit()
    finally:
        con.close()
    return login


def mobile_verify_password_credentials(raw_login, raw_password):
    login = _mobile_normalize_login(raw_login)
    password = str(raw_password or "")
    if not login or not password:
        return None
    con = sqlite3.connect(USER_DB, timeout=5)
    row = con.execute(
        "SELECT subject_id,salt,password_hash FROM mobile_password_credentials WHERE login=?",
        (login,)
    ).fetchone()
    con.close()
    if not row:
        # Keep timing less revealing for unknown logins.
        _mobile_password_hash(password, b"TrueWebDummySalt")
        return None
    try:
        actual = _mobile_password_hash(password, bytes.fromhex(str(row[1])))
        expected = bytes.fromhex(str(row[2]))
    except Exception:
        return None
    if not hmac.compare_digest(actual, expected):
        return None
    subject_id = int(row[0])
    if not get_client(subject_id):
        return None
    return subject_id


def _mobile_request_ip(request):
    # nginx is expected to replace X-Real-IP. Do not trust a client-supplied
    # X-Forwarded-For chain for authentication rate limiting.
    return str(request.headers.get("X-Real-IP") or request.remote or "unknown")[:80]


def _mobile_password_rate_limited(key):
    now = int(time.time())
    rows = [t for t in _mobile_password_failures.get(key, []) if now - t < MOBILE_PASSWORD_FAILURE_WINDOW]
    _mobile_password_failures[key] = rows
    return len(rows) >= MOBILE_PASSWORD_MAX_FAILURES


def _mobile_password_note_failure(*keys):
    now = int(time.time())
    for key in keys:
        rows = [t for t in _mobile_password_failures.get(key, []) if now - t < MOBILE_PASSWORD_FAILURE_WINDOW]
        rows.append(now)
        _mobile_password_failures[key] = rows[-MOBILE_PASSWORD_MAX_FAILURES:]


def _mobile_password_clear_failures(*keys):
    for key in keys:
        _mobile_password_failures.pop(key, None)


def _mobile_safe_error_detail(value):
    text = str(value or "").replace("\r", " ").replace("\n", " ").strip()
    text = re.sub(r"(?i)(vless|vmess|trojan|ss)://\S+", "<vpn-uri-redacted>", text)
    text = re.sub(r"(?i)bearer\s+[A-Za-z0-9._~+\-/=]+", "Bearer <redacted>", text)
    text = re.sub(r"[0-9a-fA-F]{8}-[0-9a-fA-F-]{27,}", "<uuid-redacted>", text)
    text = re.sub(r"[A-Za-z0-9_-]{40,}", "<token-redacted>", text)
    return text[:300]


def mobile_delete_account(subject_id):
    subject_id = int(subject_id)
    identity = mobile_email_identity_by_subject(subject_id)
    client = get_client(subject_id)

    # Preserve only pseudonymous anti-abuse markers. Deleting an account never
    # turns a previous user into a new user for one-time trial eligibility.
    if identity:
        email = str(identity.get("email") or "")
        if email:
            mobile_remember_trial_identity("email", email)
    mobile_remember_trial_identity("tg", subject_id)

    if client and not mobile_delete_xui_client(client):
        raise RuntimeError("Не удалось отозвать VPN-доступ")

    mobile_revoke_sessions_for_subject(subject_id)
    con = sqlite3.connect(USER_DB, timeout=5)
    try:
        con.execute("DELETE FROM mobile_password_credentials WHERE subject_id=?", (subject_id,))
        con.execute("DELETE FROM mobile_email_identities WHERE subject_id=?", (subject_id,))
        con.execute("DELETE FROM mobile_auth_codes WHERE tg_id=?", (subject_id,))
        con.commit()
    finally:
        con.close()
    return True


async def mobile_auth_password_login_handler(request):
    try:
        data = await request.json()
    except Exception:
        data = {}
    login = _mobile_normalize_login(data.get("login"))
    password = str(data.get("password") or "")
    ip = _mobile_request_ip(request)
    ip_key = "ip:" + ip
    login_key = "login:" + (login or "invalid")
    if _mobile_password_rate_limited(ip_key) or _mobile_password_rate_limited(login_key):
        return _mobile_json_error("Слишком много попыток. Попробуйте позже", 429)
    subject_id = await asyncio.to_thread(mobile_verify_password_credentials, login, password)
    if not subject_id:
        _mobile_password_note_failure(ip_key, login_key)
        return _mobile_json_error("Неверный логин или пароль", 401)
    _mobile_password_clear_failures(ip_key, login_key)
    token, expires_at = await asyncio.to_thread(mobile_issue_session, subject_id)
    identity = await asyncio.to_thread(mobile_email_identity_by_subject, subject_id)
    needs_telegram_link = bool(identity and not identity.get("telegram_tg_id"))
    return web.json_response({
        "ok": True,
        "access_token": token,
        "token_type": "Bearer",
        "expires_at": int(expires_at),
        "needs_telegram_link": bool(needs_telegram_link),
    }, headers={"Cache-Control": "no-store"})


async def mobile_account_password_handler(request):
    subject_id = mobile_auth_tg_id(request)
    try:
        data = await request.json()
    except Exception:
        data = {}
    try:
        login = await asyncio.to_thread(
            mobile_set_password_credentials,
            subject_id,
            data.get("login"),
            data.get("password"),
        )
        return web.json_response({"ok": True, "login": login}, headers={"Cache-Control": "no-store"})
    except ValueError as e:
        return _mobile_json_error(str(e), 409)
    except Exception as e:
        print("MOBILE PASSWORD SET ERROR:", subject_id, e, flush=True)
        return _mobile_json_error("Не удалось сохранить логин и пароль", 500)


async def mobile_account_delete_handler(request):
    subject_id = mobile_auth_tg_id(request)
    try:
        await asyncio.to_thread(mobile_delete_account, subject_id)
        try:
            await bot.send_message(
                ADMIN_ID,
                "🗑 <b>Аккаунт TrueWeb удалён</b>\n\n"
                f"ID: <code>{int(subject_id)}</code>\n"
                "VPN-доступ отозван, активные мобильные сессии удалены.",
                parse_mode="HTML",
            )
        except Exception:
            pass
        return web.json_response({"ok": True}, headers={"Cache-Control": "no-store"})
    except Exception as e:
        print("MOBILE ACCOUNT DELETE ERROR:", subject_id, e, flush=True)
        return _mobile_json_error("Не удалось удалить аккаунт", 500)


async def mobile_error_report_handler(request):
    subject_id = mobile_auth_tg_id(request)
    try:
        data = await request.json()
    except Exception:
        data = {}
    stage = re.sub(r"[^a-zA-Z0-9_.-]+", "_", str(data.get("stage") or "unknown"))[:64]
    error_type = re.sub(r"[^a-zA-Z0-9_.$-]+", "_", str(data.get("error_type") or "Error"))[:64]
    detail = _mobile_safe_error_detail(data.get("detail"))
    app_version = str(request.headers.get("X-App-Version") or "")[:40]
    model = str(request.headers.get("x-device-model") or "")[:120]
    os_version = str(request.headers.get("x-ver-os") or "")[:80]
    fingerprint = hashlib.sha256(f"{subject_id}|{stage}|{error_type}|{detail}".encode("utf-8")).hexdigest()
    now = int(time.time())
    last = int(_mobile_error_report_seen.get(fingerprint, 0) or 0)
    if now - last < MOBILE_ERROR_REPORT_COOLDOWN:
        return web.json_response({"ok": True, "deduplicated": True}, headers={"Cache-Control": "no-store"})
    _mobile_error_report_seen[fingerprint] = now
    # Bound memory if a large incident produces many unique fingerprints.
    if len(_mobile_error_report_seen) > 2000:
        cutoff = now - MOBILE_ERROR_REPORT_COOLDOWN * 2
        for key, ts in list(_mobile_error_report_seen.items()):
            if int(ts or 0) < cutoff:
                _mobile_error_report_seen.pop(key, None)
    try:
        await bot.send_message(
            ADMIN_ID,
            "🚨 <b>Ошибка TrueWeb Android</b>\n\n"
            f"👤 ID: <code>{int(subject_id)}</code>\n"
            f"📱 {html.escape(model or 'Android')} · Android {html.escape(os_version or '?')}\n"
            f"🏷 Версия: <code>{html.escape(app_version or '?')}</code>\n"
            f"🧩 Этап: <code>{html.escape(stage)}</code>\n"
            f"⚠️ Тип: <code>{html.escape(error_type)}</code>\n"
            f"📝 {html.escape(detail or 'без дополнительного текста')}",
            parse_mode="HTML",
        )
    except Exception as e:
        print("MOBILE ERROR REPORT TG FAILED:", e, flush=True)
    return web.json_response({"ok": True}, headers={"Cache-Control": "no-store"})


'''
    text = replace_once(text, core_anchor, core + core_anchor, "market handlers anchor")

    # Do not automatically issue another email trial after account deletion.
    trial_old = '''    trial_activated = False
    if is_new:
        # Email login must be immediately usable; no Telegram is required first.
        claim_trial(subject_id)
        trial_ms = -(MOBILE_EMAIL_TRIAL_DAYS * 24 * 60 * 60 * 1000)
        if not update_client_expiry(client, trial_ms):
            raise RuntimeError("Не удалось активировать пробный доступ")
        trial_activated = True
        mobile_record_app_acquisition(subject_id)
'''
    trial_new = '''    trial_activated = False
    if is_new and not mobile_trial_identity_seen("email", email):
        # Email login must be immediately usable; no Telegram is required first.
        claim_trial(subject_id)
        mobile_remember_trial_identity("email", email)
        trial_ms = -(MOBILE_EMAIL_TRIAL_DAYS * 24 * 60 * 60 * 1000)
        if not update_client_expiry(client, trial_ms):
            raise RuntimeError("Не удалось активировать пробный доступ")
        trial_activated = True
        mobile_record_app_acquisition(subject_id)
'''
    text = replace_once(text, trial_old, trial_new, "email trial anti-abuse")

    routes_old = '''    app.router.add_post("/api/mobile/auth/email/start", mobile_auth_email_start_handler)
    app.router.add_post("/api/mobile/auth/email/verify", mobile_auth_email_verify_handler)
    app.router.add_post("/api/mobile/auth/email/link-telegram", mobile_auth_email_link_telegram_handler)
'''
    routes_new = '''    app.router.add_post("/api/mobile/auth/email/start", mobile_auth_email_start_handler)
    app.router.add_post("/api/mobile/auth/email/verify", mobile_auth_email_verify_handler)
    app.router.add_post("/api/mobile/auth/email/link-telegram", mobile_auth_email_link_telegram_handler)
    app.router.add_post("/api/mobile/auth/password/login", mobile_auth_password_login_handler)
    app.router.add_post("/api/mobile/account/password", mobile_account_password_handler)
    app.router.add_delete("/api/mobile/account", mobile_account_delete_handler)
    app.router.add_post("/api/mobile/errors/report", mobile_error_report_handler)
'''
    text = replace_once(text, routes_old, routes_new, "market API routes")

    db_anchor = '''    con.execute("""CREATE INDEX IF NOT EXISTS idx_mobile_email_identity_tg ON mobile_email_identities(telegram_tg_id)""")
'''
    db_block = '''    con.execute("""CREATE INDEX IF NOT EXISTS idx_mobile_email_identity_tg ON mobile_email_identities(telegram_tg_id)""")
    con.execute("""
        CREATE TABLE IF NOT EXISTS mobile_password_credentials (
            login TEXT PRIMARY KEY,
            subject_id INTEGER NOT NULL UNIQUE,
            salt TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            updated_at INTEGER NOT NULL
        )
    """)
    con.execute("""CREATE INDEX IF NOT EXISTS idx_mobile_password_subject ON mobile_password_credentials(subject_id)""")
    con.execute("""
        CREATE TABLE IF NOT EXISTS mobile_trial_identity_hashes (
            identity_hash TEXT PRIMARY KEY,
            created_at INTEGER NOT NULL
        )
    """)
'''
    text = replace_once(text, db_anchor, db_block, "market DB tables")

    # Update app-identifying subscription request if a previous release string is present.
    text = text.replace('"User-Agent": "TrueWeb-Android/0.8.3"', '"User-Agent": "TrueWeb-Android/0.8.4"')

    ast.parse(text)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = BOT_PATH.with_name(BOT_PATH.name + f".before-v084-market-{stamp}")
    shutil.copy2(BOT_PATH, backup)
    BOT_PATH.write_text(text, encoding="utf-8")
    py_compile.compile(str(BOT_PATH), doraise=True)
    print("OK: TrueWeb v0.8.4 market patch применён")
    print("bot:", BOT_PATH)
    print("backup:", backup)
    print("Routes: password login, password setup, account delete, error report")
    print("Email re-registration trial protection: enabled")


if __name__ == "__main__":
    main()

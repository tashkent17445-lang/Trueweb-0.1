package ru.trueweb.vpn.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.trueweb.vpn.model.SubscriptionInfo
import ru.trueweb.vpn.model.VpnServer
import ru.trueweb.vpn.vpn.TrueWebVpnService

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    subscription: SubscriptionInfo,
    servers: List<VpnServer>,
    selectedServerId: String,
    refreshing: Boolean,
    trialLoading: Boolean,
    errorText: String?,
    vpnState: TrueWebVpnService.TunnelState,
    vpnError: String?,
    themeMode: TrueWebThemeMode,
    onConnectClick: () -> Unit,
    onTrialClick: () -> Unit,
    onRefresh: () -> Unit,
    onServerSelected: (String) -> Unit,
    onThemeChanged: (TrueWebThemeMode) -> Unit,
    onLogout: () -> Unit
) {
    var showServers by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val selected = servers.firstOrNull { it.id == selectedServerId }
        ?: servers.firstOrNull { it.id == "auto" }
        ?: VpnServer("auto", "Автовыбор", "urltest", null, true)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(trueWebBackground(themeMode))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("TrueWeb", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { showSettings = true }, modifier = Modifier.size(52.dp)) {
                Text("⚙", fontSize = 28.sp)
            }
        }

        Spacer(Modifier.height(12.dp))

        Surface(
            modifier = Modifier.fillMaxWidth().clickable { showServers = true },
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(22.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 17.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Сервер", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                    Text(if (selected.id == "auto") "⚡ ${selected.name}" else selected.name, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.weight(1f))
                Text("›", fontSize = 30.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        if (!errorText.isNullOrBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(errorText, modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
        }

        Spacer(Modifier.weight(0.7f))

        val buttonColor = when (vpnState) {
            TrueWebVpnService.TunnelState.RUNNING -> Color(0xFF123D31)
            TrueWebVpnService.TunnelState.CONNECTING -> Color(0xFF17304A)
            TrueWebVpnService.TunnelState.ERROR -> Color(0xFF3A1B22)
            TrueWebVpnService.TunnelState.STOPPED -> if (themeMode == TrueWebThemeMode.AMOLED) Color(0xFF111111) else Color(0xFF13263A)
        }

        Surface(
            modifier = Modifier.size(190.dp).shadow(if (themeMode == TrueWebThemeMode.AMOLED) 0.dp else 28.dp, CircleShape).clickable(onClick = onConnectClick),
            shape = CircleShape,
            color = buttonColor
        ) {
            Box(contentAlignment = Alignment.Center) { Text("🌐", fontSize = 92.sp) }
        }

        Spacer(Modifier.height(18.dp))
        Text(
            when (vpnState) {
                TrueWebVpnService.TunnelState.RUNNING -> "Подключено"
                TrueWebVpnService.TunnelState.CONNECTING -> "Подключение…"
                TrueWebVpnService.TunnelState.ERROR -> "Ошибка подключения — нажмите ещё раз"
                TrueWebVpnService.TunnelState.STOPPED -> when {
                    subscription.active -> "Нажмите, чтобы подключиться"
                    subscription.trialAvailable -> "Активируйте бесплатный доступ"
                    else -> "Подписка не активна"
                }
            },
            fontWeight = FontWeight.SemiBold,
            color = if (vpnState == TrueWebVpnService.TunnelState.RUNNING) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )

        if (vpnState == TrueWebVpnService.TunnelState.ERROR && !vpnError.isNullOrBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(
                vpnError,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )
        }

        if (subscription.trialAvailable) {
            Spacer(Modifier.height(14.dp))
            Button(onClick = onTrialClick, enabled = !trialLoading, shape = RoundedCornerShape(16.dp)) {
                if (trialLoading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                else Text("Получить 3 дня бесплатно", fontWeight = FontWeight.SemiBold)
            }
        }

        Spacer(Modifier.weight(0.8f))
        SubscriptionCard(subscription)
    }

    if (showServers) {
        ModalBottomSheet(onDismissRequest = { showServers = false }, containerColor = MaterialTheme.colorScheme.surface) {
            Text("Выбор сервера", modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Автовыбор сам выбирает лучший доступный маршрут.", modifier = Modifier.padding(horizontal = 24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(12.dp))
            servers.filter { it.available }.forEach { server ->
                Row(
                    modifier = Modifier.fillMaxWidth().clickable {
                        onServerSelected(server.id)
                        showServers = false
                    }.padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = server.id == selectedServerId, onClick = null)
                    Spacer(Modifier.width(10.dp))
                    Text(if (server.id == "auto") "⚡ ${server.name}" else server.name, modifier = Modifier.weight(1f))
                }
            }
            Spacer(Modifier.navigationBarsPadding().height(16.dp))
        }
    }

    if (showSettings) {
        ModalBottomSheet(onDismissRequest = { showSettings = false }, containerColor = MaterialTheme.colorScheme.surface) {
            Text("Настройки", modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Тема", modifier = Modifier.padding(horizontal = 24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
            ThemeChoice("Обычная тёмная", TrueWebThemeMode.DARK, themeMode, onThemeChanged)
            ThemeChoice("AMOLED — чистый чёрный", TrueWebThemeMode.AMOLED, themeMode, onThemeChanged)
            HorizontalDivider(Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.surfaceVariant)
            TextButton(
                onClick = { onRefresh(); showSettings = false },
                enabled = !refreshing,
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) { Text(if (refreshing) "Обновляем…" else "↻ Обновить подписку") }
            TextButton(
                onClick = { onLogout(); showSettings = false },
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) { Text("Выйти", color = MaterialTheme.colorScheme.error) }
            Spacer(Modifier.navigationBarsPadding().height(16.dp))
        }
    }
}

@Composable
private fun ThemeChoice(label: String, mode: TrueWebThemeMode, selected: TrueWebThemeMode, onChange: (TrueWebThemeMode) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onChange(mode) }.padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = mode == selected, onClick = null)
        Spacer(Modifier.width(10.dp))
        Text(label)
    }
}

@Composable
private fun SubscriptionCard(info: SubscriptionInfo) {
    Surface(modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Подписка", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                    Text(
                        when { info.trialPending -> "Пробный доступ готов"; info.active -> "Активна"; else -> "Не активна" },
                        fontWeight = FontWeight.Bold,
                        color = if (info.active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                    )
                }
                Spacer(Modifier.weight(1f))
                if (info.active && !info.unlimited) Text("${info.daysLeft} дн.", fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(10.dp))
            Text(
                when { info.trialPending -> info.expiresLabel; info.unlimited -> "Без ограничения по сроку"; info.active -> "до ${info.expiresLabel}"; else -> info.expiresLabel },
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(18.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth()) {
                Metric("Трафик", info.trafficUsed, Modifier.weight(1f))
                Metric("Устройства", info.devicesLabel, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.Start) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(4.dp))
        Text(value, fontWeight = FontWeight.Bold, fontSize = 19.sp)
    }
}

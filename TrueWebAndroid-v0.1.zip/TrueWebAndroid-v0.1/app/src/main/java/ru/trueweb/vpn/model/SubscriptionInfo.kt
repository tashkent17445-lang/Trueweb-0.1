package ru.trueweb.vpn.model

data class SubscriptionInfo(
    val active: Boolean,
    val expiresAt: String,
    val daysLeft: Int,
    val trafficUsed: String,
    val devicesUsed: Int,
    val devicesLimit: Int,
    val serverName: String,
    val latencyMs: Int?
) {
    companion object {
        val Preview = SubscriptionInfo(
            active = true,
            expiresAt = "16 октября 2026",
            daysLeft = 30,
            trafficUsed = "18.4 ГБ",
            devicesUsed = 2,
            devicesLimit = 5,
            serverName = "Автовыбор",
            latencyMs = 38
        )
    }
}

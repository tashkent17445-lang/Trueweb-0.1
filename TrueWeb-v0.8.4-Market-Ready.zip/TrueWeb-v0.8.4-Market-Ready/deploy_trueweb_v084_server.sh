#!/usr/bin/env bash
set -euo pipefail

BOT=/opt/vpn-bot/bot.py
PATCH="${1:-./trueweb_v084_market_patch.py}"
LEGAL_DIR="${2:-./legal}"
WEBROOT=/var/www/trueweb-start
STAMP="$(date +%Y%m%d-%H%M%S)"

if [ ! -f "$BOT" ]; then
  echo "ERROR: $BOT not found"
  exit 1
fi
if [ ! -f "$PATCH" ]; then
  echo "ERROR: patch not found: $PATCH"
  exit 1
fi
if [ ! -d "$LEGAL_DIR" ]; then
  echo "ERROR: legal directory not found: $LEGAL_DIR"
  exit 1
fi

echo "=== BACKUP ==="
cp -a "$BOT" "$BOT.before-v084-$STAMP"

echo "=== PATCH BACKEND ==="
python3 "$PATCH" "$BOT"
python3 -m py_compile "$BOT"

echo "=== INSTALL LEGAL PAGES ==="
mkdir -p "$WEBROOT/legal"
cp -a "$LEGAL_DIR"/. "$WEBROOT/legal/"
find "$WEBROOT/legal" -type d -exec chmod 755 {} +
find "$WEBROOT/legal" -type f -exec chmod 644 {} +

echo "=== NGINX CHECK ==="
nginx -t

echo "=== RESTART BOT ==="
systemctl restart vpn-bot.service
sleep 2
systemctl is-active --quiet vpn-bot.service

echo "=== VERIFY ROUTES IN SOURCE ==="
grep -nE '/api/mobile/(auth/password/login|account/password|account|errors/report)' "$BOT"

echo "=== VERIFY LEGAL PAGES ==="
for path in privacy terms rules deletion; do
  test -s "$WEBROOT/legal/$path/index.html"
  printf '%-10s ' "$path"
  curl -ksS -o /dev/null -w '%{http_code}\n' "https://trueweb24.ru/legal/$path/"
done

echo "=== DONE ==="
echo "Backup: $BOT.before-v084-$STAMP"

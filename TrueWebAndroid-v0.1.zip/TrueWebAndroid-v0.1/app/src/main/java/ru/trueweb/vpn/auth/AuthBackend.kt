package ru.trueweb.vpn.auth

import org.json.JSONObject
import ru.trueweb.vpn.AppConfig
import java.net.HttpURLConnection
import java.net.URL

object AuthBackend {
    /**
     * Expected backend response:
     * {"access_token":"...","refresh_token":"..."}
     *
     * The one-time code should expire quickly and be usable only once.
     */
    fun exchangeCode(code: String): Result<String> = runCatching {
        val connection = (URL("${AppConfig.API_BASE}/auth/exchange").openConnection() as HttpURLConnection)
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 10_000
            connection.readTimeout = 10_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject().put("code", code).toString()
            connection.outputStream.use { it.write(body.toByteArray()) }

            val responseCode = connection.responseCode
            val stream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (responseCode !in 200..299) error("Auth exchange failed: HTTP $responseCode $text")

            JSONObject(text).getString("access_token")
        } finally {
            connection.disconnect()
        }
    }
}

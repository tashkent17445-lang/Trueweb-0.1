package ru.trueweb.vpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import io.nekohasekai.libbox.CommandServer
import io.nekohasekai.libbox.CommandServerHandler
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.Notification as LibboxNotification
import io.nekohasekai.libbox.OverrideOptions
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.SetupOptions
import io.nekohasekai.libbox.StringIterator
import io.nekohasekai.libbox.SystemProxyStatus
import io.nekohasekai.libbox.TunOptions
import io.nekohasekai.libbox.WIFIState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import ru.trueweb.vpn.MainActivity
import ru.trueweb.vpn.R
import ru.trueweb.vpn.store.ServerStore
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InterfaceAddress
import java.util.concurrent.atomic.AtomicBoolean

class TrueWebVpnService : VpnService(), PlatformInterface, CommandServerHandler {
    enum class TunnelState { STOPPED, CONNECTING, RUNNING, ERROR }

    companion object {
        const val ACTION_START = "ru.trueweb.vpn.START"
        const val ACTION_STOP = "ru.trueweb.vpn.STOP"
        const val ACTION_RELOAD = "ru.trueweb.vpn.RELOAD"
        private const val CHANNEL_ID = "trueweb_vpn"
        private const val NOTIFICATION_ID = 1001
        private const val TAG = "TrueWebVpn"

        private val _state = MutableStateFlow(TunnelState.STOPPED)
        val state: StateFlow<TunnelState> = _state
        private val _lastError = MutableStateFlow<String?>(null)
        val lastError: StateFlow<String?> = _lastError

        @Volatile private var libboxReady = false

        fun start(context: Context) {
            val intent = Intent(context, TrueWebVpnService::class.java).setAction(ACTION_START)
            context.startForegroundService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, TrueWebVpnService::class.java).setAction(ACTION_STOP)
            context.startService(intent)
        }

        fun reload(context: Context) {
            val intent = Intent(context, TrueWebVpnService::class.java).setAction(ACTION_RELOAD)
            context.startForegroundService(intent)
        }
    }

    private val starting = AtomicBoolean(false)
    private val store by lazy { ServerStore(applicationContext) }
    private var commandServer: CommandServer? = null
    private var tunFd: ParcelFileDescriptor? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private val interfaceListeners = mutableSetOf<InterfaceUpdateListener>()

    override fun onCreate() {
        super.onCreate()
        createChannel()
        registerNetworkCallback()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                store.desiredRunning = false
                stopTunnel()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START, ACTION_RELOAD -> {
                store.desiredRunning = true
                startForeground(NOTIFICATION_ID, notification(if (intent.action == ACTION_RELOAD) "Переключаем сервер…" else "Подключение…"))
                startTunnelAsync()
            }
            else -> {
                if (store.desiredRunning) {
                    startForeground(NOTIFICATION_ID, notification("Восстанавливаем подключение…"))
                    startTunnelAsync()
                } else return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        unregisterNetworkCallback()
        stopTunnel()
        super.onDestroy()
    }

    override fun onRevoke() {
        store.desiredRunning = false
        stopTunnel()
        stopSelf()
        super.onRevoke()
    }

    private fun startTunnelAsync() {
        if (!starting.compareAndSet(false, true)) return
        Thread {
            try {
                _lastError.value = null
                _state.value = TunnelState.CONNECTING
                updateNotification("Подключение…")
                ensureLibbox()

                val servers = store.loadServers()
                val config = SingBoxConfigBuilder.build(servers, store.selectedServerId)

                stopCoreOnly()
                commandServer = CommandServer(this, this).also { it.start() }
                commandServer!!.checkConfig(config)
                commandServer!!.startOrReloadService(config, OverrideOptions())

                _lastError.value = null
                _state.value = TunnelState.RUNNING
                updateNotification("VPN подключён · ${store.selectedServer().name}")
                Log.i(TAG, "Tunnel started")
            } catch (e: Throwable) {
                Log.e(TAG, "Start failed: ${e.message}", e)
                _lastError.value = e.message?.take(240) ?: "Неизвестная ошибка VPN"
                _state.value = TunnelState.ERROR
                updateNotification("Ошибка VPN: ${e.message?.take(90) ?: "неизвестная ошибка"}")
                stopCoreOnly()
            } finally {
                starting.set(false)
            }
        }.start()
    }

    @Synchronized
    private fun ensureLibbox() {
        if (libboxReady) return
        val options = SetupOptions().apply {
            setBasePath(filesDir.absolutePath)
            setWorkingPath(getDir("singbox", 0).absolutePath)
            setTempPath(cacheDir.absolutePath)
            setFixAndroidStack(true)
        }
        Libbox.setup(options)
        libboxReady = true
        Log.i(TAG, "libbox ${Libbox.version()}")
    }

    @Synchronized
    private fun stopCoreOnly() {
        runCatching { commandServer?.closeService() }
        runCatching { commandServer?.close() }
        commandServer = null
        runCatching { tunFd?.close() }
        tunFd = null
    }

    private fun stopTunnel() {
        starting.set(false)
        stopCoreOnly()
        _lastError.value = null
        _state.value = TunnelState.STOPPED
    }

    // PlatformInterface ----------------------------------------------------
    override fun openTun(options: TunOptions): Int {
        val builder = Builder()
            .setSession("TrueWeb")
            .setMtu(options.mtu.takeIf { it > 0 } ?: 1500)

        val inet4 = options.inet4Address
        while (inet4.hasNext()) {
            val prefix = inet4.next()
            builder.addAddress(prefix.address(), prefix.prefix())
        }
        val inet6 = options.inet6Address
        while (inet6.hasNext()) {
            val prefix = inet6.next()
            builder.addAddress(prefix.address(), prefix.prefix())
        }

        var default4 = false
        val route4 = options.inet4RouteAddress
        while (route4.hasNext()) {
            val prefix = route4.next()
            if (prefix.prefix() == 0) default4 = true
            builder.addRoute(prefix.address(), prefix.prefix())
        }
        var default6 = false
        val route6 = options.inet6RouteAddress
        while (route6.hasNext()) {
            val prefix = route6.next()
            if (prefix.prefix() == 0) default6 = true
            builder.addRoute(prefix.address(), prefix.prefix())
        }
        if (!default4) builder.addRoute("0.0.0.0", 0)
        if (!default6) builder.addRoute("::", 0)

        runCatching {
            options.getDNSServerAddress()?.value?.let(builder::addDnsServer)
        }
        builder.addDnsServer("1.1.1.1")
        runCatching { builder.addDisallowedApplication(packageName) }

        tunFd?.close()
        tunFd = builder.establish() ?: error("Android не создал TUN-интерфейс")
        return tunFd!!.fd
    }

    override fun autoDetectInterfaceControl(fd: Int) {
        if (!protect(fd)) error("Не удалось защитить сокет VPN от зацикливания")
    }

    override fun usePlatformAutoDetectInterfaceControl(): Boolean = true
    override fun useProcFS(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
    override fun underNetworkExtension(): Boolean = false
    override fun includeAllNetworks(): Boolean = false

    override fun findConnectionOwner(
        ipProtocol: Int,
        sourceAddress: String,
        sourcePort: Int,
        destinationAddress: String,
        destinationPort: Int
    ): io.nekohasekai.libbox.ConnectionOwner? = io.nekohasekai.libbox.ConnectionOwner()

    override fun readWIFIState(): WIFIState? = null
    override fun clearDNSCache() {}
    override fun systemCertificates(): StringIterator? = null
    override fun sendNotification(notification: LibboxNotification?) {}
    override fun localDNSTransport(): io.nekohasekai.libbox.LocalDNSTransport? = null

    override fun getInterfaces(): NetworkInterfaceIterator? {
        val items = mutableListOf<io.nekohasekai.libbox.NetworkInterface>()
        runCatching {
            val enumeration = java.net.NetworkInterface.getNetworkInterfaces()
            while (enumeration.hasMoreElements()) {
                val networkInterface = enumeration.nextElement()
                if (!networkInterface.isUp || networkInterface.isLoopback || networkInterface.isVirtual) continue
                if (networkInterface.name.startsWith("tun") || networkInterface.name.startsWith("wg")) continue
                if (networkInterface.mtu <= 0) continue

                val item = io.nekohasekai.libbox.NetworkInterface().apply {
                    setName(networkInterface.name)
                    setIndex(networkInterface.index)
                    setMTU(networkInterface.mtu)
                    setType(interfaceType(networkInterface.name))
                    setAddresses(StringListIterator(networkInterface.interfaceAddresses.mapNotNull(::toLibboxAddressPrefix)))
                    setDNSServer(StringListIterator(emptyList()))
                }
                items.add(item)
            }
        }.onFailure { Log.w(TAG, "Interface enumeration failed", it) }
        return if (items.isEmpty()) null else NetworkInterfaceListIterator(items)
    }

    override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener?) {
        listener ?: return
        synchronized(interfaceListeners) { interfaceListeners.add(listener) }
        updateDefaultInterface()
    }

    override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener?) {
        listener ?: return
        synchronized(interfaceListeners) { interfaceListeners.remove(listener) }
    }

    // CommandServerHandler -------------------------------------------------
    override fun serviceReload() { Log.i(TAG, "libbox reloaded") }

    override fun serviceStop() {
        if (store.desiredRunning && _state.value == TunnelState.RUNNING) {
            _state.value = TunnelState.ERROR
            updateNotification("VPN-движок остановлен")
        }
    }

    override fun getSystemProxyStatus(): SystemProxyStatus? = null
    override fun setSystemProxyEnabled(enabled: Boolean) {}
    override fun writeDebugMessage(message: String?) { Log.d(TAG, "[libbox] ${message.orEmpty()}") }

    // Network tracking -----------------------------------------------------
    private fun registerNetworkCallback() {
        val manager = getSystemService(ConnectivityManager::class.java) ?: return
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = updateDefaultInterface()
            override fun onLost(network: Network) = updateDefaultInterface()
            override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) = updateDefaultInterface()
        }.also { runCatching { manager.registerNetworkCallback(request, it) } }
    }

    private fun unregisterNetworkCallback() {
        val callback = networkCallback ?: return
        runCatching { getSystemService(ConnectivityManager::class.java)?.unregisterNetworkCallback(callback) }
        networkCallback = null
    }

    private fun updateDefaultInterface() {
        val manager = getSystemService(ConnectivityManager::class.java) ?: return
        val candidates = manager.allNetworks.mapNotNull { network ->
            val caps = manager.getNetworkCapabilities(network) ?: return@mapNotNull null
            if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)) return@mapNotNull null
            val link = manager.getLinkProperties(network) ?: return@mapNotNull null
            val name = link.interfaceName ?: return@mapNotNull null
            val index = runCatching { java.net.NetworkInterface.getByName(name)?.index ?: 0 }.getOrDefault(0)
            val expensive = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
            Triple(name, index, expensive)
        }
        val current = candidates.firstOrNull() ?: return
        synchronized(interfaceListeners) {
            interfaceListeners.forEach { listener ->
                runCatching { listener.updateDefaultInterface(current.first, current.second, current.third, false) }
            }
        }
    }

    private fun interfaceType(name: String): Int = when {
        name.startsWith("wlan") || name.startsWith("wifi") -> Libbox.InterfaceTypeWIFI
        name.startsWith("rmnet") || name.startsWith("ccmni") || name.startsWith("pdp") -> Libbox.InterfaceTypeCellular
        name.startsWith("eth") -> Libbox.InterfaceTypeEthernet
        else -> Libbox.InterfaceTypeOther
    }

    // Notification ---------------------------------------------------------
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "TrueWeb VPN", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
            )
        }
    }

    private fun notification(text: String): Notification {
        val pending = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("TrueWeb")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_trueweb)
            .setContentIntent(pending)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
    }
}

private class StringListIterator(private val items: List<String>) : StringIterator {
    private var index = 0
    override fun hasNext(): Boolean = index < items.size
    override fun len(): Int = items.size
    override fun next(): String = items[index++]
}

private class NetworkInterfaceListIterator(
    private val items: List<io.nekohasekai.libbox.NetworkInterface>
) : NetworkInterfaceIterator {
    private var index = 0
    override fun hasNext(): Boolean = index < items.size
    override fun next(): io.nekohasekai.libbox.NetworkInterface = items[index++]
}

private fun toLibboxAddressPrefix(interfaceAddress: InterfaceAddress): String? {
    val address = interfaceAddress.address ?: return null
    val bits = when (address) {
        is Inet4Address -> 32
        is Inet6Address -> 128
        else -> return null
    }
    val host = address.hostAddress?.substringBefore('%')?.trim().orEmpty()
    val prefix = interfaceAddress.networkPrefixLength.toInt()
    if (host.isBlank() || prefix !in 0..bits) return null
    return "$host/$prefix"
}

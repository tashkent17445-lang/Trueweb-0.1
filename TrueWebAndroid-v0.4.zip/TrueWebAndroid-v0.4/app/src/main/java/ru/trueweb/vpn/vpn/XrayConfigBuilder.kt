package ru.trueweb.vpn.vpn

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import ru.trueweb.vpn.model.VpnServer

/**
 * Builds a native Xray-core config from the VLESS links returned by TrueWeb.
 * The server remains the source of truth for the subscription and HWID limit;
 * the APK only converts the already-authorized links into Xray JSON.
 */
object XrayConfigBuilder {
    private const val AUTO_BALANCER = "tw-auto"
    private const val OUTBOUND_PREFIX = "tw-node-"

    data class BuiltConfig(
        val json: String,
        val selectedName: String,
        val nodeCount: Int
    )

    fun build(servers: List<VpnServer>, selectedServerId: String): BuiltConfig {
        val candidates = servers
            .filter { !it.isAuto && it.available && !it.uri.isNullOrBlank() }
            .filter { it.protocol.equals("vless", ignoreCase = true) }

        require(candidates.isNotEmpty()) { "В подписке нет VLESS-серверов" }

        val parsed = candidates.mapIndexedNotNull { index, server ->
            runCatching {
                val tag = OUTBOUND_PREFIX + index.toString().padStart(3, '0')
                ParsedNode(server, tag, parseVlessOutbound(server, tag))
            }.getOrNull()
        }
        require(parsed.isNotEmpty()) { "Не удалось разобрать VLESS/XHTTP конфигурацию" }

        val selected = if (selectedServerId == "auto") {
            null
        } else {
            parsed.firstOrNull { it.server.id == selectedServerId }
                ?: throw IllegalArgumentException("Выбранный сервер больше недоступен")
        }

        val root = JSONObject()
            .put("log", JSONObject().put("loglevel", "warning"))
            .put("policy", JSONObject().put(
                "levels", JSONObject().put(
                    "8", JSONObject()
                        .put("handshake", 4)
                        .put("connIdle", 300)
                        .put("uplinkOnly", 1)
                        .put("downlinkOnly", 1)
                )
            ))
            .put("inbounds", JSONArray().put(buildTunInbound()))
            .put("outbounds", buildOutbounds(parsed))
            .put("routing", buildRouting(parsed, selected))
            .put("dns", buildDns())

        if (selected == null && parsed.size > 1) {
            root.put("observatory", JSONObject()
                .put("subjectSelector", JSONArray().put(OUTBOUND_PREFIX))
                .put("probeUrl", "https://www.gstatic.com/generate_204")
                .put("probeInterval", "10s")
                .put("enableConcurrency", true)
            )
        }

        return BuiltConfig(
            json = root.toString(),
            selectedName = selected?.server?.name ?: "Автовыбор",
            nodeCount = parsed.size
        )
    }

    private data class ParsedNode(
        val server: VpnServer,
        val tag: String,
        val outbound: JSONObject
    )

    private fun buildTunInbound(): JSONObject = JSONObject()
        .put("tag", "tun")
        .put("protocol", "tun")
        .put("settings", JSONObject()
            .put("name", "xray0")
            .put("MTU", 1500)
            .put("userLevel", 8)
        )
        .put("sniffing", JSONObject()
            .put("enabled", true)
            .put("destOverride", JSONArray().put("http").put("tls").put("quic"))
        )

    private fun buildOutbounds(nodes: List<ParsedNode>): JSONArray = JSONArray().apply {
        nodes.forEach { put(it.outbound) }
        put(JSONObject()
            .put("tag", "direct")
            .put("protocol", "freedom")
            .put("streamSettings", JSONObject().put(
                "sockopt", JSONObject()
                    .put("domainStrategy", "UseIP")
                    .put("happyEyeballs", JSONObject().put("tryDelayMs", 250).put("interleave", 2))
            ))
        )
        put(JSONObject()
            .put("tag", "block")
            .put("protocol", "blackhole")
            .put("settings", JSONObject().put("response", JSONObject().put("type", "http")))
        )
    }

    private fun buildRouting(nodes: List<ParsedNode>, selected: ParsedNode?): JSONObject {
        val routing = JSONObject()
            .put("domainStrategy", "AsIs")

        val rule = JSONObject()
            .put("type", "field")
            .put("inboundTag", JSONArray().put("tun"))
            .put("network", "tcp,udp")

        if (selected != null || nodes.size == 1) {
            rule.put("outboundTag", (selected ?: nodes.first()).tag)
            routing.put("rules", JSONArray().put(rule))
            return routing
        }

        val balancer = JSONObject()
            .put("tag", AUTO_BALANCER)
            .put("selector", JSONArray().put(OUTBOUND_PREFIX))
            .put("fallbackTag", nodes.first().tag)
            .put("strategy", JSONObject().put("type", "leastPing"))

        rule.put("balancerTag", AUTO_BALANCER)
        routing.put("balancers", JSONArray().put(balancer))
        routing.put("rules", JSONArray().put(rule))
        return routing
    }

    private fun buildDns(): JSONObject = JSONObject()
        .put("queryStrategy", "UseIPv4")
        .put("servers", JSONArray()
            .put("1.1.1.1")
            .put("8.8.8.8")
        )

    private fun parseVlessOutbound(server: VpnServer, tag: String): JSONObject {
        val raw = server.uri ?: error("Пустая VLESS-ссылка")
        val uri = Uri.parse(raw)
        require(uri.scheme.equals("vless", ignoreCase = true)) { "Поддерживается только VLESS" }

        val uuid = (uri.userInfo ?: "").substringBefore(':').trim()
        val host = uri.host?.trim().orEmpty()
        val port = uri.port.takeIf { it > 0 } ?: 443
        require(uuid.isNotBlank()) { "В VLESS-ссылке нет UUID" }
        require(host.isNotBlank()) { "В VLESS-ссылке нет адреса сервера" }

        fun q(name: String): String? = uri.getQueryParameter(name)?.trim()?.takeIf { it.isNotBlank() }

        val security = q("security") ?: "none"
        val network = q("type") ?: q("network") ?: "tcp"
        val encryption = q("encryption") ?: "none"
        val flow = q("flow")

        val settings = JSONObject()
            .put("address", host)
            .put("port", port)
            .put("id", uuid)
            .put("encryption", encryption)
            .put("level", 8)
        flow?.let { settings.put("flow", it) }

        val stream = JSONObject().put("network", network)

        when (network.lowercase()) {
            "xhttp" -> {
                val xhttp = JSONObject()
                    .put("path", q("path") ?: "/")
                q("host")?.let { xhttp.put("host", it) }
                q("mode")?.let { xhttp.put("mode", it) }
                q("extra")?.let { extraRaw ->
                    val parsedExtra = runCatching { JSONTokener(extraRaw).nextValue() }.getOrNull()
                        ?: throw IllegalArgumentException("Некорректный XHTTP extra")
                    xhttp.put("extra", parsedExtra)
                }
                stream.put("xhttpSettings", xhttp)
            }
            "ws", "websocket" -> {
                stream.put("network", "ws")
                stream.put("wsSettings", JSONObject()
                    .put("path", q("path") ?: "/")
                    .apply {
                        q("host")?.let { hostValue -> put("host", hostValue) }
                    }
                )
            }
            "grpc" -> {
                stream.put("grpcSettings", JSONObject()
                    .put("serviceName", q("serviceName") ?: q("service_name") ?: "")
                    .apply {
                        q("authority")?.let { put("authority", it) }
                        q("mode")?.let { put("multiMode", it.equals("multi", true)) }
                    }
                )
            }
            "httpupgrade" -> {
                stream.put("httpupgradeSettings", JSONObject()
                    .put("path", q("path") ?: "/")
                    .apply { q("host")?.let { put("host", it) } }
                )
            }
            "h2", "http" -> {
                stream.put("network", "h2")
                stream.put("httpSettings", JSONObject()
                    .put("path", q("path") ?: "/")
                    .apply {
                        q("host")?.let { value ->
                            put("host", JSONArray().apply {
                                value.split(',').map(String::trim).filter(String::isNotBlank).forEach(::put)
                            })
                        }
                    }
                )
            }
            "tcp", "raw" -> {
                stream.put("network", if (network.equals("raw", true)) "raw" else "tcp")
            }
            else -> throw IllegalArgumentException("Транспорт '$network' пока не поддерживается")
        }

        when (security.lowercase()) {
            "reality" -> {
                val reality = JSONObject()
                q("sni")?.let { reality.put("serverName", it) }
                q("fp")?.let { reality.put("fingerprint", it) }
                q("pbk")?.let { reality.put("publicKey", it) }
                q("sid")?.let { reality.put("shortId", it) }
                q("spx")?.let { reality.put("spiderX", it) }
                q("pqv")?.let { reality.put("mldsa65Verify", it) }
                q("alpn")?.let { alpn ->
                    reality.put("alpn", JSONArray().apply {
                        alpn.split(',').map(String::trim).filter(String::isNotBlank).forEach(::put)
                    })
                }
                require(reality.optString("publicKey").isNotBlank()) { "REALITY: нет public key (pbk)" }
                stream.put("security", "reality")
                stream.put("realitySettings", reality)
            }
            "tls" -> {
                val tls = JSONObject()
                q("sni")?.let { tls.put("serverName", it) }
                q("fp")?.let { tls.put("fingerprint", it) }
                q("alpn")?.let { alpn ->
                    tls.put("alpn", JSONArray().apply {
                        alpn.split(',').map(String::trim).filter(String::isNotBlank).forEach(::put)
                    })
                }
                q("pcs")?.let { tls.put("pinnedPeerCertSha256", it) }
                q("vcn")?.let { tls.put("verifyPeerCertByName", it) }
                stream.put("security", "tls")
                stream.put("tlsSettings", tls)
            }
            "none", "" -> stream.put("security", "none")
            else -> throw IllegalArgumentException("Security '$security' пока не поддерживается")
        }

        // XHTTP already multiplexes requests internally; Xray/v2rayNG also disables mux here.
        return JSONObject()
            .put("tag", tag)
            .put("protocol", "vless")
            .put("settings", settings)
            .put("streamSettings", stream)
            .put("mux", JSONObject().put("enabled", false).put("concurrency", -1))
    }
}

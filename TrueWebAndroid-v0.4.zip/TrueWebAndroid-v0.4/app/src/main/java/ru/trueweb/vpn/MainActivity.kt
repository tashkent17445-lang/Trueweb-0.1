package ru.trueweb.vpn

import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import ru.trueweb.vpn.api.TrueWebApi
import ru.trueweb.vpn.auth.AuthBackend
import ru.trueweb.vpn.auth.SessionStore
import ru.trueweb.vpn.model.*
import ru.trueweb.vpn.store.DeviceIdentity
import ru.trueweb.vpn.store.PendingPaymentStore
import ru.trueweb.vpn.store.RoutingStore
import ru.trueweb.vpn.store.ServerStore
import ru.trueweb.vpn.store.ThemeStore
import ru.trueweb.vpn.ui.*
import ru.trueweb.vpn.vpn.TrueWebVpnService
import ru.trueweb.vpn.work.SubscriptionRefreshWorker

class MainActivity : ComponentActivity() {
    private lateinit var sessionStore: SessionStore
    private lateinit var serverStore: ServerStore
    private lateinit var deviceIdentity: DeviceIdentity
    private lateinit var themeStore: ThemeStore
    private lateinit var pendingPaymentStore: PendingPaymentStore
    private lateinit var routingStore: RoutingStore

    private var authenticated by mutableStateOf(false)
    private var authInProgress by mutableStateOf(false)
    private var authError by mutableStateOf<String?>(null)

    private var subscription by mutableStateOf<SubscriptionInfo?>(null)
    private var servers by mutableStateOf<List<VpnServer>>(emptyList())
    private var pendingVpnMode by mutableStateOf(VpnMode.NORMAL)
    private var themeMode by mutableStateOf(TrueWebThemeMode.DARK)

    private var profileLoading by mutableStateOf(false)
    private var profileError by mutableStateOf<String?>(null)
    private var trialLoading by mutableStateOf(false)

    private var tariffs by mutableStateOf<List<TariffOption>>(emptyList())
    private var deviceProduct by mutableStateOf<DeviceProduct?>(null)
    private var devices by mutableStateOf<List<DeviceItem>>(emptyList())
    private var managementLoading by mutableStateOf(false)
    private var managementError by mutableStateOf<String?>(null)
    private var paymentLoadingProduct by mutableStateOf<String?>(null)
    private var paymentChecking by mutableStateOf(false)
    private var paymentMessage by mutableStateOf<String?>(null)

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                startVpnMode(pendingVpnMode)
            } else {
                Toast.makeText(this, "Без разрешения Android VPN подключение невозможно", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sessionStore = SessionStore(this)
        serverStore = ServerStore(this)
        deviceIdentity = DeviceIdentity(this)
        themeStore = ThemeStore(this)
        pendingPaymentStore = PendingPaymentStore(this)
        routingStore = RoutingStore(this)

        authenticated = sessionStore.isAuthenticated
        servers = serverStore.loadServers()
        themeMode = themeStore.mode

        handleIntent(intent)

        setContent {
            val vpnState by TrueWebVpnService.state.collectAsState()
            val vpnError by TrueWebVpnService.lastError.collectAsState()
            val vpnMode by TrueWebVpnService.mode.collectAsState()
            val whitelistSuggested by TrueWebVpnService.whitelistSuggested.collectAsState()
            TrueWebTheme(themeMode) {
                SideEffect {
                    val lightBars = themeMode == TrueWebThemeMode.LIGHT
                    val controller = WindowCompat.getInsetsController(window, window.decorView)
                    controller.isAppearanceLightStatusBars = lightBars
                    controller.isAppearanceLightNavigationBars = lightBars
                    @Suppress("DEPRECATION")
                    run {
                        window.statusBarColor = if (lightBars) android.graphics.Color.WHITE else android.graphics.Color.BLACK
                        window.navigationBarColor = if (lightBars) android.graphics.Color.WHITE else android.graphics.Color.BLACK
                    }
                }

                if (!authenticated) {
                    AuthScreen(
                        authInProgress = authInProgress,
                        errorText = authError,
                        themeMode = themeMode,
                        onProxyClick = { openExternal(AppConfig.TELEGRAM_PROXY_URL) },
                        onTelegramLoginClick = {
                            authError = null
                            openExternal(AppConfig.TELEGRAM_AUTH_START)
                        }
                    )
                } else {
                    val info = subscription
                    if (info == null) {
                        LoadingScreen(errorText = profileError, onRetry = { loadData(forceServers = true) })
                    } else {
                        HomeScreen(
                            subscription = info,
                            whitelistConfigured = servers.any { it.role == VpnRole.WHITELIST },
                            refreshing = profileLoading,
                            trialLoading = trialLoading,
                            errorText = profileError,
                            vpnState = vpnState,
                            vpnError = vpnError,
                            vpnMode = vpnMode,
                            whitelistSuggested = whitelistSuggested,
                            themeMode = themeMode,
                            tariffs = tariffs,
                            deviceProduct = deviceProduct,
                            devices = devices,
                            managementLoading = managementLoading,
                            managementError = managementError,
                            paymentLoadingProduct = paymentLoadingProduct,
                            paymentChecking = paymentChecking,
                            paymentMessage = paymentMessage,
                            hasPendingPayment = pendingPaymentStore.paymentId != null,
                            onConnectClick = { toggleNormalVpn(info, vpnState, vpnMode) },
                            onWhitelistClick = { toggleWhitelistVpn(info, vpnState, vpnMode) },
                            onTrialClick = { activateTrial() },
                            onRefresh = { loadData(forceServers = true) },
                            onManagementRefresh = { loadManagementData() },
                            onPay = { startPayment(it) },
                            onCheckPayment = { checkPendingPayment(poll = true) },
                            onDismissPendingPayment = { dismissPendingPayment() },
                            onDeleteDevice = { deleteDevice(it) },
                            onThemeChanged = { setTheme(it) },
                            onLogout = { logout() }
                        )
                    }
                }
            }
        }

        if (authenticated) {
            SubscriptionRefreshWorker.schedule(this)
            loadData(forceServers = serverStore.isStale() || !serverStore.hasRequiredNormalServers())
            if (pendingPaymentStore.paymentId != null) checkPendingPayment(poll = false)
        }
    }

    override fun onResume() {
        super.onResume()
        if (this::sessionStore.isInitialized && authenticated && !profileLoading) {
            servers = serverStore.loadServers()
            loadData(forceServers = serverStore.isStale() || !serverStore.hasRequiredNormalServers())
            if (serverStore.desiredRunning) TrueWebVpnService.foregroundCheck(this)
            if (this::pendingPaymentStore.isInitialized && pendingPaymentStore.paymentId != null && !paymentChecking) {
                checkPendingPayment(poll = false)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val uri = intent?.data ?: return

        val isPaymentReturn = uri.scheme == "trueweb" && uri.host == "payment" && uri.path == "/return"
        if (isPaymentReturn) {
            if (authenticated && this::pendingPaymentStore.isInitialized) {
                paymentMessage = "Проверяем оплату…"
                checkPendingPayment(poll = true)
            }
            return
        }

        val isVerifiedAppLink = uri.scheme == "https" && uri.host == "trueweb24.ru" && uri.path == "/mobile-auth/callback"
        val isAppScheme = uri.scheme == "trueweb" && uri.host == "auth" && uri.path == "/callback"
        if (!isVerifiedAppLink && !isAppScheme) return

        val error = uri.getQueryParameter("error")
        if (!error.isNullOrBlank()) {
            authError = error
            authInProgress = false
            return
        }

        val code = uri.getQueryParameter("code") ?: return
        authInProgress = true
        authError = null
        Thread {
            val result = AuthBackend.exchangeCode(code)
            runOnUiThread {
                authInProgress = false
                result.onSuccess { accessToken ->
                    sessionStore.accessToken = accessToken
                    authenticated = true
                    subscription = null
                    SubscriptionRefreshWorker.schedule(this)
                    loadData(forceServers = true)
                }.onFailure {
                    authError = "Не удалось завершить вход: ${cleanError(it)}"
                }
            }
        }.start()
    }

    private fun loadData(forceServers: Boolean) {
        if (profileLoading) return
        val token = sessionStore.accessToken ?: return
        profileLoading = true
        profileError = null

        Thread {
            if (routingStore.isStale()) {
                TrueWebApi.routing(token).onSuccess { routingStore.save(it) }
            }

            var serverError: Throwable? = null
            var catalogUpdated = false
            if (forceServers || serverStore.isStale() || !serverStore.hasRequiredNormalServers()) {
                TrueWebApi.servers(token, deviceIdentity)
                    .onSuccess {
                        serverStore.saveCatalog(it)
                        catalogUpdated = true
                    }
                    .onFailure { serverError = it }
            }

            val profileResult = TrueWebApi.me(token)
            runOnUiThread {
                profileLoading = false
                if (catalogUpdated) {
                    servers = serverStore.loadServers()
                            }

                profileResult.onSuccess {
                    subscription = it
                    profileError = serverError?.let(::serverErrorText)
                }.onFailure {
                    if ((it.message ?: "").contains("HTTP 401")) {
                        expireSession()
                    } else {
                        profileError = "Не удалось обновить данные: ${cleanError(it)}"
                    }
                }

                if (serverError != null && (serverError!!.message ?: "").contains("HTTP 401")) {
                    expireSession()
                }
            }
        }.start()
    }

    private fun loadManagementData() {
        if (managementLoading) return
        val token = sessionStore.accessToken ?: return
        managementLoading = true
        managementError = null

        Thread {
            val billing = TrueWebApi.billingCatalog(token)
            val deviceResult = TrueWebApi.devices(token, deviceIdentity)
            runOnUiThread {
                managementLoading = false
                billing.onSuccess {
                    tariffs = it.tariffs
                    deviceProduct = it.deviceProduct
                }.onFailure {
                    managementError = "Не удалось загрузить тарифы: ${cleanError(it)}"
                }
                deviceResult.onSuccess {
                    devices = it.devices
                }.onFailure {
                    val prefix = if (managementError.isNullOrBlank()) "" else "${managementError}\n"
                    managementError = prefix + "Не удалось загрузить устройства: ${cleanError(it)}"
                }
            }
        }.start()
    }

    private fun activateTrial() {
        if (trialLoading) return
        val token = sessionStore.accessToken ?: return
        trialLoading = true
        profileError = null
        Thread {
            val result = TrueWebApi.activateTrial(token)
            runOnUiThread {
                trialLoading = false
                result.onSuccess {
                    subscription = it
                    Toast.makeText(this, "Пробный доступ активирован на 3 дня", Toast.LENGTH_LONG).show()
                    loadData(forceServers = true)
                    loadManagementData()
                }.onFailure { profileError = cleanError(it) }
            }
        }.start()
    }

    private fun startPayment(product: String) {
        if (paymentLoadingProduct != null) return
        val token = sessionStore.accessToken ?: return
        paymentLoadingProduct = product
        paymentMessage = null
        managementError = null

        Thread {
            val result = TrueWebApi.createPayment(token, product)
            runOnUiThread {
                paymentLoadingProduct = null
                result.onSuccess { payment ->
                    pendingPaymentStore.paymentId = payment.id
                    paymentMessage = "Ожидаем оплату ${payment.title}"
                    openExternal(payment.confirmationUrl)
                }.onFailure {
                    managementError = "Не удалось создать платёж: ${cleanError(it)}"
                }
            }
        }.start()
    }

    private fun checkPendingPayment(poll: Boolean) {
        if (paymentChecking) return
        val token = sessionStore.accessToken ?: return
        val paymentId = pendingPaymentStore.paymentId ?: return
        paymentChecking = true

        Thread {
            var status: PaymentStatus? = null
            var lastError: Throwable? = null
            val attempts = if (poll) 10 else 1
            for (index in 0 until attempts) {
                val result = TrueWebApi.paymentStatus(token, paymentId)
                result.onSuccess { status = it }.onFailure { lastError = it }
                val current = status
                if (current != null && (current.processed || current.status == "canceled")) break
                if (index < attempts - 1) Thread.sleep(1500)
            }

            runOnUiThread {
                paymentChecking = false
                when {
                    status?.processed == true -> {
                        pendingPaymentStore.clear()
                        paymentMessage = null
                        Toast.makeText(this, "Оплата прошла успешно. Подписка обновлена.", Toast.LENGTH_LONG).show()
                        loadData(forceServers = true)
                        loadManagementData()
                    }
                    status?.status == "canceled" -> {
                        pendingPaymentStore.clear()
                        paymentMessage = null
                        Toast.makeText(this, "Платёж отменён", Toast.LENGTH_SHORT).show()
                    }
                    status?.status == "succeeded" -> {
                        paymentMessage = "Оплата получена, завершаем активацию…"
                        loadData(forceServers = true)
                    }
                    lastError != null -> {
                        managementError = "Не удалось проверить оплату: ${cleanError(lastError!!)}"
                    }
                    else -> paymentMessage = "Платёж пока не завершён"
                }
            }
        }.start()
    }

    private fun dismissPendingPayment() {
        pendingPaymentStore.clear()
        paymentMessage = null
        managementError = null
        Toast.makeText(
            this,
            "Платёж скрыт. Это не отменяет его в ЮKassa.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun deleteDevice(deviceId: Int) {
        if (managementLoading) return
        val token = sessionStore.accessToken ?: return
        managementLoading = true
        managementError = null
        Thread {
            val result = TrueWebApi.deleteDevice(token, deviceId, deviceIdentity)
            runOnUiThread {
                managementLoading = false
                result.onSuccess {
                    Toast.makeText(this, "Устройство удалено", Toast.LENGTH_SHORT).show()
                    loadManagementData()
                    loadData(forceServers = true)
                }.onFailure {
                    managementError = "Не удалось удалить устройство: ${cleanError(it)}"
                }
            }
        }.start()
    }

    private fun toggleNormalVpn(
        info: SubscriptionInfo,
        state: TrueWebVpnService.TunnelState,
        mode: VpnMode
    ) {
        if ((state == TrueWebVpnService.TunnelState.RUNNING || state == TrueWebVpnService.TunnelState.CONNECTING) &&
            mode == VpnMode.NORMAL
        ) {
            TrueWebVpnService.stop(this)
            return
        }
        if (!info.active) {
            Toast.makeText(this, "Сначала активируйте пробный период или подписку", Toast.LENGTH_SHORT).show()
            return
        }
        prepareAndStartVpn(VpnMode.NORMAL)
    }

    private fun toggleWhitelistVpn(
        info: SubscriptionInfo,
        state: TrueWebVpnService.TunnelState,
        mode: VpnMode
    ) {
        if ((state == TrueWebVpnService.TunnelState.RUNNING || state == TrueWebVpnService.TunnelState.CONNECTING) &&
            mode == VpnMode.WHITELIST
        ) {
            TrueWebVpnService.stop(this)
            return
        }
        if (!info.active) {
            Toast.makeText(this, "Сначала активируйте пробный период или подписку", Toast.LENGTH_SHORT).show()
            return
        }
        prepareAndStartVpn(VpnMode.WHITELIST)
    }

    private fun prepareAndStartVpn(mode: VpnMode) {
        val token = sessionStore.accessToken ?: return
        Thread {
            var error: Throwable? = null
            if (routingStore.isStale()) {
                TrueWebApi.routing(token).onSuccess { routingStore.save(it) }
            }
            if (serverStore.isStale() || !serverStore.hasRequiredNormalServers() ||
                (mode == VpnMode.WHITELIST && serverStore.whitelistServers().isEmpty())
            ) {
                TrueWebApi.servers(token, deviceIdentity)
                    .onSuccess { serverStore.saveCatalog(it) }
                    .onFailure { error = it }
            }
            runOnUiThread {
                servers = serverStore.loadServers()
                if (error != null) {
                    profileError = serverErrorText(error!!)
                    Toast.makeText(this, profileError, Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }
                when {
                    !serverStore.hasRequiredNormalServers() -> {
                        profileError = "Не получены основной и резервный входы TrueWeb"
                        Toast.makeText(this, profileError, Toast.LENGTH_LONG).show()
                    }
                    mode == VpnMode.WHITELIST && serverStore.whitelistServers().isEmpty() -> {
                        Toast.makeText(this, "Белые списки пока недоступны", Toast.LENGTH_SHORT).show()
                    }
                    else -> requestVpnPermissionAndStart(mode)
                }
            }
        }.start()
    }

    private fun requestVpnPermissionAndStart(mode: VpnMode) {
        pendingVpnMode = mode
        serverStore.desiredMode = mode
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) vpnPermissionLauncher.launch(prepareIntent)
        else startVpnMode(mode)
    }

    private fun startVpnMode(mode: VpnMode) {
        when (mode) {
            VpnMode.NORMAL -> TrueWebVpnService.startNormal(this)
            VpnMode.WHITELIST -> TrueWebVpnService.startWhitelist(this)
        }
    }

    private fun setTheme(mode: TrueWebThemeMode) {
        themeStore.mode = mode
        themeMode = mode
    }

    private fun logout() {
        val token = sessionStore.accessToken
        TrueWebVpnService.stop(this)
        SubscriptionRefreshWorker.cancel(this)
        sessionStore.clear()
        serverStore.clearRuntime()
        pendingPaymentStore.clear()
        subscription = null
        servers = emptyList()
        pendingVpnMode = VpnMode.NORMAL
        profileError = null
        managementError = null
        authenticated = false
        if (!token.isNullOrBlank()) Thread { TrueWebApi.logout(token) }.start()
    }

    private fun expireSession() {
        TrueWebVpnService.stop(this)
        SubscriptionRefreshWorker.cancel(this)
        sessionStore.clear()
        authenticated = false
        subscription = null
        authError = "Сессия истекла. Войдите через Telegram ещё раз."
    }

    private fun serverErrorText(t: Throwable): String {
        val msg = cleanError(t)
        return when {
            msg.contains("Лимит устройств", ignoreCase = true) -> msg
            (t.message ?: "").contains("HTTP 403") -> "Лимит устройств исчерпан. Откройте «Управление подпиской» и удалите старое устройство или добавьте слот."
            else -> "Не удалось обновить серверы: $msg"
        }
    }

    private fun openExternal(url: String) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            .onFailure { Toast.makeText(this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show() }
    }

    private fun cleanError(t: Throwable): String {
        val raw = t.message ?: "неизвестная ошибка"
        return raw.substringAfter(": ", raw).take(220)
    }
}

@Composable
private fun LoadingScreen(errorText: String?, onRetry: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(28.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (errorText.isNullOrBlank()) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(18.dp))
                    Text("Загружаем подписку…", color = MaterialTheme.colorScheme.onBackground)
                } else {
                    Text(errorText, color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onRetry) { Text("Повторить") }
                }
            }
        }
    }
}
